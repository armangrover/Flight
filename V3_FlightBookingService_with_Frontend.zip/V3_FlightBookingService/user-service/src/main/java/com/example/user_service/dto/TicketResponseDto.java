package com.example.user_service.dto;

import java.time.LocalDateTime;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class TicketResponseDto {

    private Long id;
    private String ticketNumber;
    private Long bookingId;
    private Long flightId;
    private Long userId;
    private String seatNumber;
    private LocalDateTime issueDate;
    private String ticketStatus;
}
