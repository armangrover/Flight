package com.example.user_service.service.impl;

import java.time.LocalDate;
import java.util.List;

import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import com.example.user_service.client.BookingClient;
import com.example.user_service.client.FlightClient;
import com.example.user_service.client.TicketClient;
import com.example.user_service.dto.BookingResponseDto;
import com.example.user_service.dto.TicketResponseDto;
import com.example.user_service.dto.UserRequestDto;
import com.example.user_service.dto.UserBookingHistoryDto;
import com.example.user_service.dto.UserResponseDto;
import com.example.user_service.entity.User;
import com.example.user_service.exception.UserNotFoundException;
import com.example.user_service.repository.UserRepository;
import com.example.user_service.service.UserService;

import feign.FeignException;

@Service
public class UserServiceImpl implements UserService {

    private final UserRepository userRepository;
    private final PasswordEncoder passwordEncoder;
    private final BookingClient bookingClient;
    private final FlightClient flightClient;
    private final TicketClient ticketClient;

    public UserServiceImpl(
            UserRepository userRepository,
            PasswordEncoder passwordEncoder,
            BookingClient bookingClient,
            FlightClient flightClient,
            TicketClient ticketClient) {
        this.userRepository = userRepository;
        this.passwordEncoder = passwordEncoder;
        this.bookingClient = bookingClient;
        this.flightClient = flightClient;
        this.ticketClient = ticketClient;
    }

    @Override
    public UserResponseDto createUser(UserRequestDto userRequestDto) {
        validateUserRequest(userRequestDto);
        User user = mapToEntity(userRequestDto);
        User savedUser = userRepository.save(user);
        return mapToResponseDto(savedUser);
    }

    @Override
    public List<UserResponseDto> getAllUsers() {
        return userRepository.findAll()
                .stream()
                .map(this::mapToResponseDto)
                .toList();
    }

    @Override
    public UserResponseDto getUserById(Long id) {
        User user = findUserById(id);
        return mapToResponseDto(user);
    }

    @Override
    public UserResponseDto getUserByEmail(String email) {
        User user = findUserByEmail(email);
        return mapToResponseDto(user);
    }

    @Override
    public List<UserBookingHistoryDto> getBookingHistoryByEmail(String email) {
        User user = findUserByEmail(email);
        return bookingClient.getBookingsByUserId(user.getId())
                .stream()
                .map(this::mapToBookingHistoryDto)
                .toList();
    }

    @Override
    public UserResponseDto updateUser(Long id, UserRequestDto userRequestDto) {
        validateUserRequest(userRequestDto);
        User existingUser = findUserById(id);

        existingUser.setFirstName(userRequestDto.getFirstName());
        existingUser.setLastName(userRequestDto.getLastName());
        existingUser.setEmail(userRequestDto.getEmail());
        existingUser.setPhoneNumber(userRequestDto.getPhoneNumber());
        existingUser.setPassword(passwordEncoder.encode(userRequestDto.getPassword()));
        existingUser.setDateOfBirth(userRequestDto.getDateOfBirth());
        existingUser.setGender(userRequestDto.getGender());
        existingUser.setNationality(userRequestDto.getNationality());
        existingUser.setPassportNumber(userRequestDto.getPassportNumber());
        existingUser.setAddress(userRequestDto.getAddress());

        User updatedUser = userRepository.save(existingUser);
        return mapToResponseDto(updatedUser);
    }

    @Override
    public UserResponseDto updateUserByEmail(String email, UserRequestDto userRequestDto) {
        validateUserRequest(userRequestDto);
        User existingUser = findUserByEmail(email);

        existingUser.setFirstName(userRequestDto.getFirstName());
        existingUser.setLastName(userRequestDto.getLastName());
        existingUser.setEmail(userRequestDto.getEmail());
        existingUser.setPhoneNumber(userRequestDto.getPhoneNumber());
        existingUser.setPassword(passwordEncoder.encode(userRequestDto.getPassword()));
        existingUser.setDateOfBirth(userRequestDto.getDateOfBirth());
        existingUser.setGender(userRequestDto.getGender());
        existingUser.setNationality(userRequestDto.getNationality());
        existingUser.setPassportNumber(userRequestDto.getPassportNumber());
        existingUser.setAddress(userRequestDto.getAddress());

        User updatedUser = userRepository.save(existingUser);
        return mapToResponseDto(updatedUser);
    }

    @Override
    public void deleteUser(Long id) {
        User user = findUserById(id);
        userRepository.delete(user);
    }

    private User findUserById(Long id) {
        return userRepository.findById(id)
                .orElseThrow(() -> new UserNotFoundException("User not found with id: " + id));
    }

    private User findUserByEmail(String email) {
        return userRepository.findByEmail(email)
                .orElseThrow(() -> new UserNotFoundException("User not found with email: " + email));
    }

    private UserBookingHistoryDto mapToBookingHistoryDto(BookingResponseDto booking) {
        return UserBookingHistoryDto.builder()
                .booking(booking)
                .flight(flightClient.getFlightById(booking.getFlightId()))
                .ticket(findTicketByBookingId(booking.getId()))
                .seatNumber(booking.getSeatNumber())
                .bookingStatus(booking.getBookingStatus())
                .bookingDate(booking.getBookingDate())
                .fare(booking.getTotalFare())
                .build();
    }

    private TicketResponseDto findTicketByBookingId(Long bookingId) {
        try {
            return ticketClient.getTicketByBookingId(bookingId);
        } catch (FeignException.NotFound exception) {
            return null;
        }
    }

    private void validateUserRequest(UserRequestDto userRequestDto) {
        if (userRequestDto.getDateOfBirth().isAfter(LocalDate.now())) {
            throw new IllegalArgumentException("Date of birth cannot be in the future");
        }
    }

    private User mapToEntity(UserRequestDto userRequestDto) {
        return User.builder()
                .firstName(userRequestDto.getFirstName())
                .lastName(userRequestDto.getLastName())
                .email(userRequestDto.getEmail())
                .phoneNumber(userRequestDto.getPhoneNumber())
                .password(passwordEncoder.encode(userRequestDto.getPassword()))
                .dateOfBirth(userRequestDto.getDateOfBirth())
                .gender(userRequestDto.getGender())
                .nationality(userRequestDto.getNationality())
                .passportNumber(userRequestDto.getPassportNumber())
                .address(userRequestDto.getAddress())
                .role("ROLE_USER")
                .build();
    }

    private UserResponseDto mapToResponseDto(User user) {
        return UserResponseDto.builder()
                .id(user.getId())
                .firstName(user.getFirstName())
                .lastName(user.getLastName())
                .email(user.getEmail())
                .phoneNumber(user.getPhoneNumber())
                .dateOfBirth(user.getDateOfBirth())
                .gender(user.getGender())
                .nationality(user.getNationality())
                .passportNumber(user.getPassportNumber())
                .address(user.getAddress())
                .role(user.getRole())
                .build();
    }
}
