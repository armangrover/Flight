package com.example.user_service.client;

import java.util.List;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

import com.example.user_service.dto.BookingResponseDto;

@FeignClient(name = "booking-service-client", url = "${booking.service.url}")
public interface BookingClient {

    @GetMapping("/bookings/user/{userId}")
    List<BookingResponseDto> getBookingsByUserId(@PathVariable("userId") Long userId);
}
