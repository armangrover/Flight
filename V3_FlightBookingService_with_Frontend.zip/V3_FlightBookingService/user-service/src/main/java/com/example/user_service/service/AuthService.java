package com.example.user_service.service;

import com.example.user_service.dto.AuthResponseDto;
import com.example.user_service.dto.LoginRequestDto;
import com.example.user_service.dto.UserRequestDto;

public interface AuthService {

    AuthResponseDto register(UserRequestDto userRequestDto);

    AuthResponseDto login(LoginRequestDto loginRequestDto);
}
