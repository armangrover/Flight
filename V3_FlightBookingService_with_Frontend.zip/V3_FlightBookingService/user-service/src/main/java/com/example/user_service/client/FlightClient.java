package com.example.user_service.client;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

import com.example.user_service.dto.FlightResponseDto;

@FeignClient(name = "flight-service-client", url = "${flight.service.url}")
public interface FlightClient {

    @GetMapping("/flights/{id}")
    FlightResponseDto getFlightById(@PathVariable("id") Long id);
}
