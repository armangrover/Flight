package com.example.user_service.client;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

import com.example.user_service.dto.TicketResponseDto;

@FeignClient(name = "ticket-service-client", url = "${ticket.service.url}")
public interface TicketClient {

    @GetMapping("/tickets/booking/{bookingId}")
    TicketResponseDto getTicketByBookingId(@PathVariable("bookingId") Long bookingId);
}
