package com.example.user_service.dto;

import java.math.BigDecimal;
import java.time.LocalDateTime;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class BookingResponseDto {

    private Long id;
    private String bookingReference;
    private Long userId;
    private Long flightId;
    private Long seatId;
    private String seatNumber;
    private LocalDateTime bookingDate;
    private String bookingStatus;
    private String paymentStatus;
    private BigDecimal totalFare;
}
