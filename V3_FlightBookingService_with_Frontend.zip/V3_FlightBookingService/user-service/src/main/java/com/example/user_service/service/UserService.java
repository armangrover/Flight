package com.example.user_service.service;

import java.util.List;

import com.example.user_service.dto.UserRequestDto;
import com.example.user_service.dto.UserBookingHistoryDto;
import com.example.user_service.dto.UserResponseDto;

public interface UserService {

    UserResponseDto createUser(UserRequestDto userRequestDto);

    List<UserResponseDto> getAllUsers();

    UserResponseDto getUserById(Long id);

    UserResponseDto getUserByEmail(String email);

    List<UserBookingHistoryDto> getBookingHistoryByEmail(String email);

    UserResponseDto updateUser(Long id, UserRequestDto userRequestDto);

    UserResponseDto updateUserByEmail(String email, UserRequestDto userRequestDto);

    void deleteUser(Long id);
}
