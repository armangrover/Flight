package com.example.user_service.dto;

import java.math.BigDecimal;
import java.time.LocalDateTime;

import lombok.Builder;
import lombok.Getter;

@Getter
@Builder
public class UserBookingHistoryDto {

    private BookingResponseDto booking;
    private FlightResponseDto flight;
    private TicketResponseDto ticket;
    private String seatNumber;
    private String bookingStatus;
    private LocalDateTime bookingDate;
    private BigDecimal fare;
}
