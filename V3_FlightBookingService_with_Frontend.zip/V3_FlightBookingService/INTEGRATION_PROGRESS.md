# Integration Progress

This document tracks the integration work added after the basic CRUD microservices were created. Keep this file updated after every integration step so it is easy to see what is complete, what still needs verification, and what is planned next.

## Current Goal

Build a fully working backend workflow for the Flight Booking System before adding production-grade improvements.

Primary workflow:

```text
User -> Search Flights -> Select Seat -> Create Booking -> Reserve Seat -> Generate Ticket
```

## Service Ports

| Service | Port | Status |
|---|---:|---|
| `flight-service` | `8081` | Running individually |
| `user-service` | `8082` | Running individually |
| `search-service` | `8083` | Running individually |
| `booking-service` | `8084` | Running individually |
| `seat-service` | `8085` | Running individually |
| `ticket-service` | `8086` | Running individually |

## Integration Features Added

### 1. Search Service Uses Flight Search Endpoint

Status: Completed

What changed:

- Added `GET /flights/search` in `flight-service`.
- Updated `search-service` Feign client to call `flight-service` search endpoint.
- `search-service` no longer fetches all flights and filters everything locally.
- `search-service` still stores every search request in `search_service_db`.

Services involved:

- `flight-service`
- `search-service`

How to verify:

```http
GET http://localhost:8083/search?source=Delhi&destination=Mumbai&departureDate=2026-08-15&numberOfPassengers=1&travelClass=Economy
```

Expected result:

- Response contains matching flights from `flight-service`.
- A new search history row is created in `search_service_db`.

Important endpoint:

```http
GET http://localhost:8081/flights/search?source=Delhi&destination=Mumbai&departureDate=2026-08-15&numberOfPassengers=1
```

### 2. Booking Service Points To Flight Service On Port 8081

Status: Completed

What changed:

- Updated `booking-service` configuration so its Feign client points to `flight-service` at `http://localhost:8081`.

Services involved:

- `booking-service`
- `flight-service`

How to verify:

Create a booking using a valid `userId`, `flightId`, and `seatId`.

```http
POST http://localhost:8084/bookings
```

Request body:

```json
{
  "userId": 1,
  "flightId": 1,
  "seatId": 1,
  "bookingStatus": "CONFIRMED",
  "paymentStatus": "PAID",
  "totalFare": 6500.00
}
```

Expected result:

- Booking is created.
- Booking response contains a generated `bookingReference`.
- Selected seat becomes `RESERVED` in `seat-service`.

### 3. Booking Response Includes Seat Number

Status: Completed

What changed:

- `booking-service` now fetches seat details from `seat-service`.
- `BookingResponseDto` now includes `seatNumber`.
- This gives downstream services and the frontend a trusted seat label from the backend.

Services involved:

- `booking-service`
- `seat-service`

How to verify:

```http
GET http://localhost:8084/bookings/1
```

Expected result:

```json
{
  "id": 1,
  "bookingReference": "BKG-6510EBBEC1",
  "userId": 1,
  "flightId": 1,
  "seatId": 1,
  "seatNumber": "12A",
  "bookingStatus": "CONFIRMED",
  "paymentStatus": "PAID",
  "totalFare": 6500.00
}
```

### 4. Ticket Service Uses Booking Data For Ticket Generation

Status: Completed

What changed:

- `ticket-service` verifies booking through `booking-service`.
- `ticket-service` now gets `userId`, `flightId`, and `seatNumber` from booking data.
- Client no longer needs to send `seatNumber`.
- If `ticketStatus` is not provided, it defaults to `ISSUED`.

Services involved:

- `ticket-service`
- `booking-service`

How to verify:

Create a ticket for a booking that does not already have a ticket.

```http
POST http://localhost:8086/tickets/generate
```

Request body:

```json
{
  "bookingId": 2
}
```

Expected result:

```json
{
  "id": 2,
  "ticketNumber": "TKT-XXXXXXXXXX",
  "bookingId": 2,
  "flightId": 1,
  "userId": 1,
  "seatNumber": "12B",
  "ticketStatus": "ISSUED"
}
```

## Verified End-To-End Test Data

The following test data has been used successfully:

| Data Type | ID | Notes |
|---|---:|---|
| Flight | `1` | `AI901`, Delhi to Mumbai |
| User | `1` | `aman.seed@example.com` |
| Seat | `1` | `12A`, reserved after booking |
| Seat | `2` | `12B`, available after initial seed |
| Booking | `1` | Confirmed booking for seat `12A` |
| Ticket | `1` | Issued for booking `1` |

## Full Backend Workflow Verification

Use this checklist to confirm the backend is working end to end.

### Step 1: Create Or Verify User

```http
GET http://localhost:8082/users/1
```

Expected:

- User exists.

### Step 2: Create Or Verify Flight

```http
GET http://localhost:8081/flights/1
```

Expected:

- Flight exists.

### Step 3: Create Or Verify Seat

```http
GET http://localhost:8085/seats/1
```

Expected:

- Seat exists.
- Seat belongs to the selected flight.

### Step 4: Search Flights

```http
GET http://localhost:8083/search?source=Delhi&destination=Mumbai&departureDate=2026-08-15&numberOfPassengers=1&travelClass=Economy
```

Expected:

- Search returns the matching flight.

### Step 5: Create Booking

```http
POST http://localhost:8084/bookings
```

Request body:

```json
{
  "userId": 1,
  "flightId": 1,
  "seatId": 2,
  "bookingStatus": "CONFIRMED",
  "paymentStatus": "PAID",
  "totalFare": 6500.00
}
```

Expected:

- Booking is created.
- Response includes `seatNumber`.
- Seat status becomes `RESERVED`.

### Step 6: Generate Ticket

```http
POST http://localhost:8086/tickets/generate
```

Request body:

```json
{
  "bookingId": 2
}
```

Expected:

- Ticket is created.
- Ticket contains `bookingId`, `flightId`, `userId`, and `seatNumber`.
- `ticketStatus` is `ISSUED`.

## Remaining Integration Work

These are intentionally postponed until the basic backend workflow is fully verified.

### Near-Term Backend Integration

- Confirm booking creation works repeatedly with different seats.
- Add or verify update flow for booking seat changes.
- Verify ticket generation works with booking-derived seat data after service restart.
- Decide whether ticket generation should happen manually through `ticket-service` or automatically after booking.

### Later Production Improvements

- Atomic seat reservation for concurrent bookings.
- Distributed transaction compensation.
- Booking cancellation lifecycle.
- Ticket cancellation linked to booking cancellation.
- Flight `availableSeats` synchronization after booking and cancellation.
- Authentication and user login.
- API gateway.
- Service discovery.
- Centralized configuration.

## How To Know A Feature Is Complete

A feature should be considered complete when all of these are true:

- The related services compile successfully.
- The related services start successfully.
- The API can be called from Postman or frontend.
- The response contains the expected data.
- The database record is created or updated correctly.
- Any required downstream service call works through OpenFeign.
- The feature is documented in this file and in `API_REFERENCE.md` if it changes API behavior.

## Documentation Rule For Future Iterations

After each integration step:

- Add a short entry under `Integration Features Added`.
- Add or update the verification request.
- Update `Remaining Integration Work`.
- Update `API_REFERENCE.md` if endpoint behavior, request body, or response body changes.
