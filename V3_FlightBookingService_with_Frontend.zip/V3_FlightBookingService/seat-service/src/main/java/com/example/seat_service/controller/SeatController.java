package com.example.seat_service.controller;

import java.net.URI;
import java.util.List;

import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.support.ServletUriComponentsBuilder;

import com.example.seat_service.dto.SeatRequestDto;
import com.example.seat_service.dto.SeatResponseDto;
import com.example.seat_service.service.SeatService;

import jakarta.validation.Valid;

@RestController
@RequestMapping("/seats")
@Validated
@CrossOrigin(origins = "http://localhost:5173")
public class SeatController {

    private final SeatService seatService;

    public SeatController(SeatService seatService) {
        this.seatService = seatService;
    }

    @PostMapping
    public ResponseEntity<SeatResponseDto> createSeat(@Valid @RequestBody SeatRequestDto seatRequestDto) {
        SeatResponseDto createdSeat = seatService.createSeat(seatRequestDto);
        URI location = ServletUriComponentsBuilder.fromCurrentRequest()
                .path("/{id}")
                .buildAndExpand(createdSeat.getId())
                .toUri();
        return ResponseEntity.created(location).body(createdSeat);
    }

    @GetMapping
    public ResponseEntity<List<SeatResponseDto>> getAllSeats() {
        return ResponseEntity.ok(seatService.getAllSeats());
    }

    @GetMapping("/{id}")
    public ResponseEntity<SeatResponseDto> getSeatById(@PathVariable Long id) {
        return ResponseEntity.ok(seatService.getSeatById(id));
    }

    @PutMapping("/{id}")
    public ResponseEntity<SeatResponseDto> updateSeat(
            @PathVariable Long id,
            @Valid @RequestBody SeatRequestDto seatRequestDto) {
        return ResponseEntity.ok(seatService.updateSeat(id, seatRequestDto));
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteSeat(@PathVariable Long id) {
        seatService.deleteSeat(id);
        return ResponseEntity.noContent().build();
    }

    @GetMapping("/flight/{flightId}")
    public ResponseEntity<List<SeatResponseDto>> getSeatsByFlightId(@PathVariable Long flightId) {
        return ResponseEntity.ok(seatService.getSeatsByFlightId(flightId));
    }

    @PutMapping("/{id}/reserve")
    public ResponseEntity<SeatResponseDto> reserveSeat(@PathVariable Long id) {
        return ResponseEntity.ok(seatService.reserveSeat(id));
    }

    @PutMapping("/{id}/release")
    public ResponseEntity<SeatResponseDto> releaseSeat(@PathVariable Long id) {
        return ResponseEntity.ok(seatService.releaseSeat(id));
    }
}
