package com.example.seat_service.dto;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalTime;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class FlightResponseDto {

    private Long id;
    private String flightNumber;
    private String airline;
    private String source;
    private String destination;
    private LocalDate departureDate;
    private LocalTime departureTime;
    private LocalDate arrivalDate;
    private LocalTime arrivalTime;
    private String duration;
    private BigDecimal price;
    private Integer availableSeats;
    private Integer totalSeats;
    private String flightStatus;
    private String aircraftType;
    private String terminal;
    private String gate;
}
