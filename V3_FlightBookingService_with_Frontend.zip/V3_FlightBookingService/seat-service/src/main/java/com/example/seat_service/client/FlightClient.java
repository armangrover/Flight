package com.example.seat_service.client;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PutMapping;

import com.example.seat_service.dto.FlightResponseDto;

@FeignClient(name = "flight-service-client", url = "${flight.service.url}")
public interface FlightClient {

    @PutMapping("/flights/{id}/decrease-available-seats")
    FlightResponseDto decreaseAvailableSeats(@PathVariable("id") Long id);

    @PutMapping("/flights/{id}/increase-available-seats")
    FlightResponseDto increaseAvailableSeats(@PathVariable("id") Long id);
}
