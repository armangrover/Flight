package com.example.seat_service.service;

import java.util.List;

import com.example.seat_service.dto.SeatRequestDto;
import com.example.seat_service.dto.SeatResponseDto;

public interface SeatService {

    SeatResponseDto createSeat(SeatRequestDto seatRequestDto);

    List<SeatResponseDto> getAllSeats();

    SeatResponseDto getSeatById(Long id);

    SeatResponseDto updateSeat(Long id, SeatRequestDto seatRequestDto);

    void deleteSeat(Long id);

    List<SeatResponseDto> getSeatsByFlightId(Long flightId);

    SeatResponseDto reserveSeat(Long id);

    SeatResponseDto releaseSeat(Long id);
}
