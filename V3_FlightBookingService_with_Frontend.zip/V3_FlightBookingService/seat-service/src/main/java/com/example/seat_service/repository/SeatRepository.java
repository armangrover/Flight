package com.example.seat_service.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.seat_service.entity.Seat;

public interface SeatRepository extends JpaRepository<Seat, Long> {

    List<Seat> findByFlightId(Long flightId);
}
