# API Reference

This document lists every REST endpoint currently implemented across the Flight Booking System microservices. All services are independent Spring Boot applications with their own database and communicate through REST/OpenFeign, not shared database access.

## Service Ports

| Service | Port | Database |
|---|---:|---|
| `flight-service` | `8081` | `flight_service_db` |
| `user-service` | `8082` | `user_service_db` |
| `search-service` | `8083` | `search_service_db` |
| `booking-service` | `8084` | `booking_service_db` |
| `seat-service` | `8085` | `seat_service_db` |
| `ticket-service` | `8086` | `ticket_service_db` |

## Authentication

Protected endpoints require:

```http
Authorization: Bearer <jwt-token>
```

Roles used by the backend:

| Role | Purpose |
|---|---|
| `ROLE_USER` | Profile, booking, cancellation, ticket generation/download |
| `ROLE_ADMIN` | Administrative CRUD such as flights, seats, all users, all bookings |

## Common Error Shape

```json
{
  "timestamp": "2026-07-21T10:30:00",
  "status": 404,
  "error": "Not Found",
  "message": "Flight not found with id: 99",
  "path": "/flights/99"
}
```

## Auth APIs

Service: `user-service`

| Method | URL | Auth | Role | Request Body | Response Body | Description |
|---|---|---|---|---|---|---|
| `POST` | `/auth/register` | No | Public | `UserRequestDto` | `AuthResponseDto` | Registers a user, hashes password with BCrypt, assigns `ROLE_USER`, and returns JWT. |
| `POST` | `/auth/login` | No | Public | `LoginRequestDto` | `AuthResponseDto` | Authenticates by email/password and returns JWT. |

Register request:

```json
{
  "firstName": "Aman",
  "lastName": "Sharma",
  "email": "aman.sharma@example.com",
  "phoneNumber": "9876543210",
  "password": "P@ssw0rd123",
  "dateOfBirth": "1998-04-15",
  "gender": "Male",
  "nationality": "Indian",
  "passportNumber": "N1234567",
  "address": "New Delhi, India"
}
```

Login request:

```json
{
  "email": "aman.sharma@example.com",
  "password": "P@ssw0rd123"
}
```

Auth response:

```json
{
  "token": "eyJhbGciOiJIUzI1NiJ9...",
  "tokenType": "Bearer",
  "userId": 1,
  "email": "aman.sharma@example.com",
  "role": "ROLE_USER"
}
```

## User Service

Base URL: `http://localhost:8082`

| Method | URL | Auth | Role | Request Body | Response Body | Description |
|---|---|---|---|---|---|---|
| `POST` | `/users` | Yes | `ROLE_ADMIN` | `UserRequestDto` | `UserResponseDto` | Admin creates a user. |
| `GET` | `/users` | Yes | `ROLE_ADMIN` | None | `List<UserResponseDto>` | Returns all users. |
| `GET` | `/users/me` | Yes | `ROLE_USER` | None | `UserResponseDto` | Returns the current authenticated user profile. |
| `GET` | `/users/me/bookings` | Yes | `ROLE_USER` | None | `List<UserBookingHistoryDto>` | Returns the current user's booking history with booking, flight, seat, and ticket details. |
| `GET` | `/users/{id}` | Yes | `ROLE_USER`, `ROLE_ADMIN` | None | `UserResponseDto` | Returns a user by ID. |
| `PUT` | `/users/me` | Yes | `ROLE_USER` | `UserRequestDto` | `UserResponseDto` | Updates the current authenticated user's profile. |
| `PUT` | `/users/{id}` | Yes | `ROLE_ADMIN` | `UserRequestDto` | `UserResponseDto` | Admin updates a user by ID. |
| `DELETE` | `/users/{id}` | Yes | `ROLE_ADMIN` | None | None | Admin deletes a user. |

`UserResponseDto` example:

```json
{
  "id": 1,
  "firstName": "Aman",
  "lastName": "Sharma",
  "email": "aman.sharma@example.com",
  "phoneNumber": "9876543210",
  "dateOfBirth": "1998-04-15",
  "gender": "Male",
  "nationality": "Indian",
  "passportNumber": "N1234567",
  "address": "New Delhi, India",
  "role": "ROLE_USER"
}
```

## Flight Service

Base URL: `http://localhost:8081`

| Method | URL | Auth | Role | Request Body | Response Body | Description |
|---|---|---|---|---|---|---|
| `POST` | `/flights` | Yes | `ROLE_ADMIN` | `FlightRequestDto` | `FlightResponseDto` | Creates a flight. |
| `GET` | `/flights` | No | Public | None | `List<FlightResponseDto>` | Lists all flights. |
| `GET` | `/flights/{id}` | No | Public | None | `FlightResponseDto` | Returns a flight by ID. |
| `GET` | `/flights/search` | No | Public | Query params | `List<FlightResponseDto>` | Searches flights by route, date, and passenger count. |
| `PUT` | `/flights/{id}` | Yes | `ROLE_ADMIN` | `FlightRequestDto` | `FlightResponseDto` | Updates a flight. |
| `PUT` | `/flights/{id}/decrease-available-seats` | Yes | `ROLE_USER`, `ROLE_ADMIN` | None | `FlightResponseDto` | Decrements available seats after a seat is reserved. |
| `PUT` | `/flights/{id}/increase-available-seats` | Yes | `ROLE_USER`, `ROLE_ADMIN` | None | `FlightResponseDto` | Increments available seats after a seat is released. |
| `DELETE` | `/flights/{id}` | Yes | `ROLE_ADMIN` | None | None | Deletes a flight. |

Search example:

```http
GET /flights/search?source=Delhi&destination=Mumbai&departureDate=2026-08-15&numberOfPassengers=2
```

`FlightRequestDto` example:

```json
{
  "flightNumber": "AI101",
  "airline": "Air India",
  "source": "Delhi",
  "destination": "Mumbai",
  "departureDate": "2026-08-15",
  "departureTime": "09:30:00",
  "arrivalDate": "2026-08-15",
  "arrivalTime": "11:45:00",
  "duration": "2h 15m",
  "price": 6500.00,
  "availableSeats": 120,
  "totalSeats": 180,
  "flightStatus": "SCHEDULED",
  "aircraftType": "Boeing 737",
  "terminal": "T2",
  "gate": "A12"
}
```

## Search Service

Base URL: `http://localhost:8083`

| Method | URL | Auth | Role | Request Body | Response Body | Description |
|---|---|---|---|---|---|---|
| `GET` | `/search` | No | Public | Query params | `List<SearchResponseDto>` | Stores search history and returns matching flights from `flight-service`. |

Search example:

```http
GET /search?source=Delhi&destination=Mumbai&departureDate=2026-08-15&returnDate=2026-08-20&numberOfPassengers=2&travelClass=Economy
```

## Seat Service

Base URL: `http://localhost:8085`

| Method | URL | Auth | Role | Request Body | Response Body | Description |
|---|---|---|---|---|---|---|
| `POST` | `/seats` | Yes | `ROLE_ADMIN` | `SeatRequestDto` | `SeatResponseDto` | Creates a seat for a flight. |
| `GET` | `/seats` | Yes | `ROLE_USER`, `ROLE_ADMIN` | None | `List<SeatResponseDto>` | Lists all seats. |
| `GET` | `/seats/{id}` | Yes | `ROLE_USER`, `ROLE_ADMIN` | None | `SeatResponseDto` | Returns a seat by ID. |
| `PUT` | `/seats/{id}` | Yes | `ROLE_ADMIN` | `SeatRequestDto` | `SeatResponseDto` | Updates a seat. |
| `DELETE` | `/seats/{id}` | Yes | `ROLE_ADMIN` | None | None | Deletes a seat. |
| `GET` | `/seats/flight/{flightId}` | Yes | `ROLE_USER`, `ROLE_ADMIN` | None | `List<SeatResponseDto>` | Lists seats for a flight. |
| `PUT` | `/seats/{id}/reserve` | Yes | `ROLE_USER`, `ROLE_ADMIN` | None | `SeatResponseDto` | Reserves a seat and decreases `flight-service.availableSeats`. |
| `PUT` | `/seats/{id}/release` | Yes | `ROLE_USER`, `ROLE_ADMIN` | None | `SeatResponseDto` | Releases a seat and increases `flight-service.availableSeats`. |

`SeatRequestDto` example:

```json
{
  "flightId": 1,
  "seatNumber": "12A",
  "seatType": "Window",
  "seatClass": "Economy",
  "price": 6500.00,
  "status": "AVAILABLE"
}
```

## Booking Service

Base URL: `http://localhost:8084`

| Method | URL | Auth | Role | Request Body | Response Body | Description |
|---|---|---|---|---|---|---|
| `POST` | `/bookings` | Yes | `ROLE_USER` | `BookingRequestDto` | `BookingResponseDto` | Creates a booking after verifying user, flight, and seat, then reserves the seat. |
| `GET` | `/bookings` | Yes | `ROLE_ADMIN` | None | `List<BookingResponseDto>` | Returns all bookings. |
| `GET` | `/bookings/{id}` | Yes | `ROLE_USER`, `ROLE_ADMIN` | None | `BookingResponseDto` | Returns a booking by ID. |
| `GET` | `/bookings/user/{userId}` | Yes | `ROLE_USER`, `ROLE_ADMIN` | None | `List<BookingResponseDto>` | Returns all bookings for a user. |
| `PUT` | `/bookings/{id}` | Yes | `ROLE_USER`, `ROLE_ADMIN` | `BookingRequestDto` | `BookingResponseDto` | Updates a booking and re-reserves seats if the selected seat changes. |
| `PUT` | `/bookings/{id}/cancel` | Yes | `ROLE_USER`, `ROLE_ADMIN` | None | `BookingResponseDto` | Cancels a booking without deleting it, releases the seat, syncs flight seats, and cancels the ticket if one exists. |
| `DELETE` | `/bookings/{id}` | Yes | `ROLE_USER`, `ROLE_ADMIN` | None | None | Compatibility endpoint; now performs cancellation instead of physical deletion. |

`BookingRequestDto` example:

```json
{
  "userId": 1,
  "flightId": 1,
  "seatId": 10,
  "bookingStatus": "CONFIRMED",
  "paymentStatus": "PAID",
  "totalFare": 6500.00
}
```

`BookingResponseDto` example:

```json
{
  "id": 1,
  "bookingReference": "BKG-1A2B3C4D5E",
  "userId": 1,
  "flightId": 1,
  "seatId": 10,
  "seatNumber": "12A",
  "bookingDate": "2026-07-21T10:30:00",
  "bookingStatus": "CONFIRMED",
  "paymentStatus": "PAID",
  "totalFare": 6500.00
}
```

## Ticket Service

Base URL: `http://localhost:8086`

| Method | URL | Auth | Role | Request Body | Response Body | Description |
|---|---|---|---|---|---|---|
| `POST` | `/tickets` | Yes | `ROLE_USER` | `TicketRequestDto` | `TicketResponseDto` | Generates a ticket from a valid booking. |
| `POST` | `/tickets/generate` | Yes | `ROLE_USER` | `TicketRequestDto` | `TicketResponseDto` | Alternate ticket generation endpoint. |
| `GET` | `/tickets` | Yes | `ROLE_ADMIN` | None | `List<TicketResponseDto>` | Returns all tickets. |
| `GET` | `/tickets/{id}` | Yes | `ROLE_USER`, `ROLE_ADMIN` | None | `TicketResponseDto` | Returns a ticket by ID. |
| `GET` | `/tickets/booking/{bookingId}` | Yes | `ROLE_USER`, `ROLE_ADMIN` | None | `TicketResponseDto` | Returns a ticket by booking ID. |
| `PUT` | `/tickets/{id}` | Yes | `ROLE_USER`, `ROLE_ADMIN` | `TicketRequestDto` | `TicketResponseDto` | Updates a ticket from verified booking data. |
| `PUT` | `/tickets/{id}/cancel` | Yes | `ROLE_USER`, `ROLE_ADMIN` | None | `TicketResponseDto` | Cancels a ticket by ticket ID. |
| `PUT` | `/tickets/booking/{bookingId}/cancel` | Yes | `ROLE_USER`, `ROLE_ADMIN` | None | `TicketResponseDto` | Cancels a ticket by booking ID. Used by `booking-service`. |
| `GET` | `/tickets/{id}/download` | Yes | `ROLE_USER`, `ROLE_ADMIN` | None | `application/pdf` bytes | Downloads a simple PDF ticket. |
| `DELETE` | `/tickets/{id}` | Yes | `ROLE_ADMIN` | None | None | Deletes a ticket record. |

`TicketRequestDto` example:

```json
{
  "bookingId": 1,
  "ticketStatus": "ISSUED"
}
```

`TicketResponseDto` example:

```json
{
  "id": 1,
  "ticketNumber": "TKT-1A2B3C4D5E",
  "bookingId": 1,
  "flightId": 1,
  "userId": 1,
  "seatNumber": "12A",
  "issueDate": "2026-07-21T10:35:00",
  "ticketStatus": "ISSUED"
}
```

## OpenFeign Communication

| Caller | Client | Target Service | Target Endpoint | Purpose |
|---|---|---|---|---|
| `search-service` | `FlightClient` | `flight-service` | `GET /flights/search` | Search flights without reading the flight database directly. |
| `booking-service` | `UserClient` | `user-service` | `GET /users/{id}` | Verify user exists before booking. |
| `booking-service` | `FlightClient` | `flight-service` | `GET /flights/{id}` | Verify flight exists before booking. |
| `booking-service` | `SeatClient` | `seat-service` | `GET /seats/{id}` | Verify seat exists and belongs to the selected flight. |
| `booking-service` | `SeatClient` | `seat-service` | `PUT /seats/{id}/reserve` | Reserve selected seat during booking creation/update. |
| `booking-service` | `SeatClient` | `seat-service` | `PUT /seats/{id}/release` | Release seat during cancellation or failed booking rollback. |
| `booking-service` | `TicketClient` | `ticket-service` | `PUT /tickets/booking/{bookingId}/cancel` | Cancel ticket when a booking is cancelled. |
| `seat-service` | `FlightClient` | `flight-service` | `PUT /flights/{id}/decrease-available-seats` | Decrease flight seat count when a seat is reserved. |
| `seat-service` | `FlightClient` | `flight-service` | `PUT /flights/{id}/increase-available-seats` | Increase flight seat count when a seat is released. |
| `ticket-service` | `BookingClient` | `booking-service` | `GET /bookings/{id}` | Verify booking and resolve seat/user/flight IDs. |
| `ticket-service` | `FlightClient` | `flight-service` | `GET /flights/{id}` | Fetch flight details for PDF generation. |
| `ticket-service` | `UserClient` | `user-service` | `GET /users/{id}` | Fetch passenger name for PDF generation. |
| `user-service` | `BookingClient` | `booking-service` | `GET /bookings/user/{userId}` | Build user booking history. |
| `user-service` | `FlightClient` | `flight-service` | `GET /flights/{id}` | Add flight details to booking history. |
| `user-service` | `TicketClient` | `ticket-service` | `GET /tickets/booking/{bookingId}` | Add ticket details to booking history when available. |

## Frontend Workflow Summary

1. Register or login through `user-service` and store the returned JWT.
2. Search/list flights through public `search-service` or `flight-service` endpoints.
3. Fetch seats for the selected flight with `GET /seats/flight/{flightId}` using the JWT.
4. Create booking with `POST /bookings`; booking-service verifies user, flight, seat, reserves the seat, and seat-service syncs flight availability.
5. Generate ticket with `POST /tickets/generate`.
6. Download the PDF ticket with `GET /tickets/{id}/download`.
7. Cancel booking with `PUT /bookings/{id}/cancel`; booking-service marks the booking cancelled, releases the seat, updates flight availability, and cancels the ticket if it exists.
