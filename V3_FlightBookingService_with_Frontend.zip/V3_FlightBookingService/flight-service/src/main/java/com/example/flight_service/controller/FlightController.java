package com.example.flight_service.controller;

import java.net.URI;
import java.time.LocalDate;
import java.util.List;

import org.springframework.http.ResponseEntity;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.support.ServletUriComponentsBuilder;

import com.example.flight_service.dto.FlightRequestDto;
import com.example.flight_service.dto.FlightResponseDto;
import com.example.flight_service.service.FlightService;

import jakarta.validation.Valid;

@RestController
@RequestMapping("/flights")
@Validated
@CrossOrigin(origins = "http://localhost:5173")
public class FlightController {

    private final FlightService flightService;

    public FlightController(FlightService flightService) {
        this.flightService = flightService;
    }

    @PostMapping
    public ResponseEntity<FlightResponseDto> createFlight(@Valid @RequestBody FlightRequestDto flightRequestDto) {
        FlightResponseDto createdFlight = flightService.createFlight(flightRequestDto);
        URI location = ServletUriComponentsBuilder.fromCurrentRequest()
                .path("/{id}")
                .buildAndExpand(createdFlight.getId())
                .toUri();
        return ResponseEntity.created(location).body(createdFlight);
    }

    @GetMapping
    public ResponseEntity<List<FlightResponseDto>> getAllFlights() {
        return ResponseEntity.ok(flightService.getAllFlights());
    }

    @GetMapping("/{id}")
    public ResponseEntity<FlightResponseDto> getFlightById(@PathVariable Long id) {
        return ResponseEntity.ok(flightService.getFlightById(id));
    }

    @GetMapping("/search")
    public ResponseEntity<List<FlightResponseDto>> searchFlights(
            @RequestParam String source,
            @RequestParam String destination,
            @RequestParam @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate departureDate,
            @RequestParam Integer numberOfPassengers) {
        return ResponseEntity.ok(flightService.searchFlights(
                source,
                destination,
                departureDate,
                numberOfPassengers));
    }

    @PutMapping("/{id}")
    public ResponseEntity<FlightResponseDto> updateFlight(
            @PathVariable Long id,
            @Valid @RequestBody FlightRequestDto flightRequestDto) {
        return ResponseEntity.ok(flightService.updateFlight(id, flightRequestDto));
    }

    @PutMapping("/{id}/decrease-available-seats")
    public ResponseEntity<FlightResponseDto> decreaseAvailableSeats(@PathVariable Long id) {
        return ResponseEntity.ok(flightService.decreaseAvailableSeats(id));
    }

    @PutMapping("/{id}/increase-available-seats")
    public ResponseEntity<FlightResponseDto> increaseAvailableSeats(@PathVariable Long id) {
        return ResponseEntity.ok(flightService.increaseAvailableSeats(id));
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteFlight(@PathVariable Long id) {
        flightService.deleteFlight(id);
        return ResponseEntity.noContent().build();
    }
}
