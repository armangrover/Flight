package com.example.flight_service.service;

import java.time.LocalDate;
import java.util.List;

import com.example.flight_service.dto.FlightRequestDto;
import com.example.flight_service.dto.FlightResponseDto;

public interface FlightService {

    FlightResponseDto createFlight(FlightRequestDto flightRequestDto);

    List<FlightResponseDto> getAllFlights();

    FlightResponseDto getFlightById(Long id);

    List<FlightResponseDto> searchFlights(
            String source,
            String destination,
            LocalDate departureDate,
            Integer numberOfPassengers);

    FlightResponseDto updateFlight(Long id, FlightRequestDto flightRequestDto);

    FlightResponseDto decreaseAvailableSeats(Long id);

    FlightResponseDto increaseAvailableSeats(Long id);

    void deleteFlight(Long id);
}
