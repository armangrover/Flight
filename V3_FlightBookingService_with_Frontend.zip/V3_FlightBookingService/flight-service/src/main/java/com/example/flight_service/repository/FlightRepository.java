package com.example.flight_service.repository;

import java.time.LocalDate;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.flight_service.entity.Flight;

public interface FlightRepository extends JpaRepository<Flight, Long> {

    List<Flight> findBySourceIgnoreCaseAndDestinationIgnoreCaseAndDepartureDateAndAvailableSeatsGreaterThanEqual(
            String source,
            String destination,
            LocalDate departureDate,
            Integer availableSeats);
}
