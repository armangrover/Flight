package com.example.ticket_service.client;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

import com.example.ticket_service.dto.BookingResponseDto;

@FeignClient(name = "booking-service-client", url = "${booking.service.url}")
public interface BookingClient {

    @GetMapping("/bookings/{id}")
    BookingResponseDto getBookingById(@PathVariable("id") Long id);
}
