package com.example.ticket_service.client;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

import com.example.ticket_service.dto.UserResponseDto;

@FeignClient(name = "user-service-client", url = "${user.service.url}")
public interface UserClient {

    @GetMapping("/users/{id}")
    UserResponseDto getUserById(@PathVariable("id") Long id);
}
