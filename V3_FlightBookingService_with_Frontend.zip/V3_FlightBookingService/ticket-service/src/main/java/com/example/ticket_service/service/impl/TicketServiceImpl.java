package com.example.ticket_service.service.impl;

import java.io.ByteArrayOutputStream;
import java.time.LocalDateTime;
import java.util.List;
import java.util.UUID;

import org.springframework.stereotype.Service;

import com.example.ticket_service.client.BookingClient;
import com.example.ticket_service.client.FlightClient;
import com.example.ticket_service.client.UserClient;
import com.example.ticket_service.dto.BookingResponseDto;
import com.example.ticket_service.dto.FlightResponseDto;
import com.example.ticket_service.dto.TicketRequestDto;
import com.example.ticket_service.dto.TicketResponseDto;
import com.example.ticket_service.dto.UserResponseDto;
import com.example.ticket_service.entity.Ticket;
import com.example.ticket_service.exception.TicketNotFoundException;
import com.example.ticket_service.repository.TicketRepository;
import com.example.ticket_service.service.TicketService;
import com.lowagie.text.Document;
import com.lowagie.text.DocumentException;
import com.lowagie.text.Font;
import com.lowagie.text.FontFactory;
import com.lowagie.text.PageSize;
import com.lowagie.text.Paragraph;
import com.lowagie.text.Phrase;
import com.lowagie.text.pdf.PdfPCell;
import com.lowagie.text.pdf.PdfPTable;
import com.lowagie.text.pdf.PdfWriter;

import feign.FeignException;

@Service
public class TicketServiceImpl implements TicketService {

    private static final String CANCELLED = "CANCELLED";
    private static final String ISSUED = "ISSUED";

    private final TicketRepository ticketRepository;
    private final BookingClient bookingClient;
    private final FlightClient flightClient;
    private final UserClient userClient;

    public TicketServiceImpl(
            TicketRepository ticketRepository,
            BookingClient bookingClient,
            FlightClient flightClient,
            UserClient userClient) {
        this.ticketRepository = ticketRepository;
        this.bookingClient = bookingClient;
        this.flightClient = flightClient;
        this.userClient = userClient;
    }

    @Override
    public TicketResponseDto createTicket(TicketRequestDto ticketRequestDto) {
        return generateTicket(ticketRequestDto);
    }

    @Override
    public TicketResponseDto generateTicket(TicketRequestDto ticketRequestDto) {
        validateTicketRequest(ticketRequestDto);
        BookingResponseDto booking = verifyBooking(ticketRequestDto.getBookingId());

        Ticket ticket = Ticket.builder()
                .ticketNumber(generateTicketNumber())
                .bookingId(booking.getId())
                .flightId(booking.getFlightId())
                .userId(booking.getUserId())
                .seatNumber(booking.getSeatNumber())
                .issueDate(LocalDateTime.now())
                .ticketStatus(resolveTicketStatus(ticketRequestDto.getTicketStatus()))
                .build();

        Ticket savedTicket = ticketRepository.save(ticket);
        return mapToResponseDto(savedTicket);
    }

    @Override
    public List<TicketResponseDto> getAllTickets() {
        return ticketRepository.findAll()
                .stream()
                .map(this::mapToResponseDto)
                .toList();
    }

    @Override
    public TicketResponseDto getTicketById(Long id) {
        return mapToResponseDto(findTicketById(id));
    }

    @Override
    public TicketResponseDto getTicketByBookingId(Long bookingId) {
        Ticket ticket = ticketRepository.findByBookingId(bookingId)
                .orElseThrow(() -> new TicketNotFoundException("Ticket not found for booking id: " + bookingId));
        return mapToResponseDto(ticket);
    }

    @Override
    public TicketResponseDto updateTicket(Long id, TicketRequestDto ticketRequestDto) {
        validateTicketRequest(ticketRequestDto);
        BookingResponseDto booking = verifyBooking(ticketRequestDto.getBookingId());
        Ticket existingTicket = findTicketById(id);

        existingTicket.setBookingId(booking.getId());
        existingTicket.setFlightId(booking.getFlightId());
        existingTicket.setUserId(booking.getUserId());
        existingTicket.setSeatNumber(booking.getSeatNumber());
        existingTicket.setTicketStatus(resolveTicketStatus(ticketRequestDto.getTicketStatus()));

        Ticket updatedTicket = ticketRepository.save(existingTicket);
        return mapToResponseDto(updatedTicket);
    }

    @Override
    public TicketResponseDto cancelTicket(Long id) {
        Ticket ticket = findTicketById(id);
        ticket.setTicketStatus(CANCELLED);
        Ticket updatedTicket = ticketRepository.save(ticket);
        return mapToResponseDto(updatedTicket);
    }

    @Override
    public TicketResponseDto cancelTicketByBookingId(Long bookingId) {
        Ticket ticket = ticketRepository.findByBookingId(bookingId)
                .orElseThrow(() -> new TicketNotFoundException("Ticket not found for booking id: " + bookingId));
        ticket.setTicketStatus(CANCELLED);
        Ticket updatedTicket = ticketRepository.save(ticket);
        return mapToResponseDto(updatedTicket);
    }

    @Override
    public byte[] generateTicketPdf(Long id) {
        Ticket ticket = findTicketById(id);
        BookingResponseDto booking = getBookingDetails(ticket.getBookingId());
        FlightResponseDto flight = getFlightDetails(ticket.getFlightId());
        UserResponseDto user = getUserDetails(ticket.getUserId());

        try (ByteArrayOutputStream outputStream = new ByteArrayOutputStream()) {
            Document document = new Document(PageSize.A4);
            PdfWriter.getInstance(document, outputStream);
            document.open();

            Font titleFont = FontFactory.getFont(FontFactory.HELVETICA_BOLD, 18);
            Font subtitleFont = FontFactory.getFont(FontFactory.HELVETICA_BOLD, 12);

            Paragraph title = new Paragraph("Flight Booking Ticket", titleFont);
            title.setAlignment(Paragraph.ALIGN_CENTER);
            title.setSpacingAfter(16);
            document.add(title);

            Paragraph subtitle = new Paragraph("Ticket Details", subtitleFont);
            subtitle.setSpacingAfter(8);
            document.add(subtitle);

            PdfPTable table = new PdfPTable(2);
            table.setWidthPercentage(100);
            table.setWidths(new float[] { 35, 65 });

            addRow(table, "Passenger Name", buildPassengerName(user));
            addRow(table, "Booking ID", String.valueOf(booking.getId()));
            addRow(table, "Ticket ID", String.valueOf(ticket.getId()));
            addRow(table, "Ticket Number", ticket.getTicketNumber());
            addRow(table, "Flight Number", flight.getFlightNumber());
            addRow(table, "Airline", flight.getAirline());
            addRow(table, "Source", flight.getSource());
            addRow(table, "Destination", flight.getDestination());
            addRow(table, "Departure Date", String.valueOf(flight.getDepartureDate()));
            addRow(table, "Departure Time", String.valueOf(flight.getDepartureTime()));
            addRow(table, "Arrival Date", String.valueOf(flight.getArrivalDate()));
            addRow(table, "Arrival Time", String.valueOf(flight.getArrivalTime()));
            addRow(table, "Seat Number", ticket.getSeatNumber());
            addRow(table, "Terminal", flight.getTerminal());
            addRow(table, "Gate", flight.getGate());
            addRow(table, "Booking Status", booking.getBookingStatus());
            addRow(table, "Ticket Status", ticket.getTicketStatus());
            addRow(table, "Fare", String.valueOf(booking.getTotalFare()));
            addRow(table, "Generation Date", String.valueOf(LocalDateTime.now()));

            document.add(table);
            document.close();
            return outputStream.toByteArray();
        } catch (DocumentException exception) {
            throw new IllegalStateException("Unable to generate ticket PDF");
        } catch (java.io.IOException exception) {
            throw new IllegalStateException("Unable to write ticket PDF");
        }
    }

    @Override
    public void deleteTicket(Long id) {
        Ticket ticket = findTicketById(id);
        ticketRepository.delete(ticket);
    }

    private Ticket findTicketById(Long id) {
        return ticketRepository.findById(id)
                .orElseThrow(() -> new TicketNotFoundException("Ticket not found with id: " + id));
    }

    private void validateTicketRequest(TicketRequestDto ticketRequestDto) {
        resolveTicketStatus(ticketRequestDto.getTicketStatus());
    }

    private BookingResponseDto verifyBooking(Long bookingId) {
        BookingResponseDto booking = getBookingDetails(bookingId);
        if (CANCELLED.equalsIgnoreCase(booking.getBookingStatus())) {
            throw new IllegalArgumentException("Cannot generate ticket for a cancelled booking");
        }
        if (booking.getSeatNumber() == null || booking.getSeatNumber().isBlank()) {
            throw new IllegalArgumentException("Booking does not contain seat number");
        }
        return booking;
    }

    private BookingResponseDto getBookingDetails(Long bookingId) {
        try {
            return bookingClient.getBookingById(bookingId);
        } catch (FeignException.NotFound exception) {
            throw new IllegalArgumentException("Booking not found with id: " + bookingId);
        } catch (FeignException exception) {
            throw new IllegalStateException("Unable to verify booking-service at this time");
        }
    }

    private FlightResponseDto getFlightDetails(Long flightId) {
        try {
            return flightClient.getFlightById(flightId);
        } catch (FeignException.NotFound exception) {
            throw new IllegalArgumentException("Flight not found with id: " + flightId);
        } catch (FeignException exception) {
            throw new IllegalStateException("Unable to verify flight-service at this time");
        }
    }

    private UserResponseDto getUserDetails(Long userId) {
        try {
            return userClient.getUserById(userId);
        } catch (FeignException.NotFound exception) {
            throw new IllegalArgumentException("User not found with id: " + userId);
        } catch (FeignException exception) {
            throw new IllegalStateException("Unable to verify user-service at this time");
        }
    }

    private void addRow(PdfPTable table, String label, String value) {
        Font labelFont = FontFactory.getFont(FontFactory.HELVETICA_BOLD, 10);
        Font valueFont = FontFactory.getFont(FontFactory.HELVETICA, 10);

        PdfPCell labelCell = new PdfPCell(new Phrase(label, labelFont));
        PdfPCell valueCell = new PdfPCell(new Phrase(value == null ? "" : value, valueFont));
        labelCell.setPadding(8);
        valueCell.setPadding(8);
        table.addCell(labelCell);
        table.addCell(valueCell);
    }

    private String buildPassengerName(UserResponseDto user) {
        String firstName = user.getFirstName() == null ? "" : user.getFirstName();
        String lastName = user.getLastName() == null ? "" : user.getLastName();
        return (firstName + " " + lastName).trim();
    }

    private String generateTicketNumber() {
        return "TKT-" + UUID.randomUUID().toString().replace("-", "").substring(0, 10).toUpperCase();
    }

    private String normalizeStatus(String status) {
        return status.trim().toUpperCase();
    }

    private String resolveTicketStatus(String status) {
        if (status == null || status.isBlank()) {
            return ISSUED;
        }
        return normalizeStatus(status);
    }

    private TicketResponseDto mapToResponseDto(Ticket ticket) {
        return TicketResponseDto.builder()
                .id(ticket.getId())
                .ticketNumber(ticket.getTicketNumber())
                .bookingId(ticket.getBookingId())
                .flightId(ticket.getFlightId())
                .userId(ticket.getUserId())
                .seatNumber(ticket.getSeatNumber())
                .issueDate(ticket.getIssueDate())
                .ticketStatus(ticket.getTicketStatus())
                .build();
    }
}
