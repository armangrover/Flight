package com.example.ticket_service.dto;

import java.time.LocalDateTime;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class TicketResponseDto {

    private Long id;
    private String ticketNumber;
    private Long bookingId;
    private Long flightId;
    private Long userId;
    private String seatNumber;
    private LocalDateTime issueDate;
    private String ticketStatus;
}
