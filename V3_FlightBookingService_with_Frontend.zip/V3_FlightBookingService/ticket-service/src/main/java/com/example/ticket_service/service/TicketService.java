package com.example.ticket_service.service;

import java.util.List;

import com.example.ticket_service.dto.TicketRequestDto;
import com.example.ticket_service.dto.TicketResponseDto;

public interface TicketService {

    TicketResponseDto createTicket(TicketRequestDto ticketRequestDto);

    TicketResponseDto generateTicket(TicketRequestDto ticketRequestDto);

    List<TicketResponseDto> getAllTickets();

    TicketResponseDto getTicketById(Long id);

    TicketResponseDto getTicketByBookingId(Long bookingId);

    TicketResponseDto updateTicket(Long id, TicketRequestDto ticketRequestDto);

    TicketResponseDto cancelTicket(Long id);

    TicketResponseDto cancelTicketByBookingId(Long bookingId);

    byte[] generateTicketPdf(Long id);

    void deleteTicket(Long id);
}
