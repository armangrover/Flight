# Flight Booking System Architecture

## Overview

The Flight Booking System is designed as a set of independent Spring Boot microservices. Each service owns its own database, business logic, REST APIs, and internal package structure. Services communicate over HTTP using OpenFeign where cross-service coordination is required.

This architecture keeps the system modular, easier to scale, and safer to evolve because each service can be developed and deployed independently.

## Microservice Interaction Diagram

```mermaid
flowchart LR
    Client[Client / Frontend / API Consumer]

    Client --> FlightService[flight-service<br/>:8080]
    Client --> UserService[user-service<br/>:8082]
    Client --> SearchService[search-service<br/>:8083]
    Client --> BookingService[booking-service<br/>:8084]
    Client --> SeatService[seat-service<br/>:8085]
    Client --> TicketService[ticket-service<br/>:8086]

    SearchService -->|OpenFeign| FlightService
    BookingService -->|OpenFeign| UserService
    BookingService -->|OpenFeign| FlightService
    BookingService -->|OpenFeign| SeatService
    TicketService -->|OpenFeign| BookingService

    FlightService --> FlightDB[(flight_service_db)]
    UserService --> UserDB[(user_service_db)]
    SearchService --> SearchDB[(search_service_db)]
    BookingService --> BookingDB[(booking_service_db)]
    SeatService --> SeatDB[(seat_service_db)]
    TicketService --> TicketDB[(ticket_service_db)]
```

## Request Flow

At a high level, the system follows a client-to-service REST architecture:

1. The client calls a microservice REST endpoint.
2. The controller receives the HTTP request and performs request binding and validation.
3. The service layer applies business rules.
4. If needed, the service calls another microservice through OpenFeign.
5. The repository layer persists or retrieves data from the service-owned MySQL database.
6. The service maps entities to DTOs and returns the response.
7. Global exception handling converts failures into consistent API error responses.

## Booking Flow

The booking flow is coordinated mainly by `booking-service`.

### Booking creation flow

1. Client sends `POST /bookings` to `booking-service`.
2. `booking-service` validates the request.
3. `booking-service` verifies the user by calling `user-service`.
4. `booking-service` verifies the flight by calling `flight-service`.
5. `booking-service` verifies the seat by calling `seat-service`.
6. `booking-service` checks that the seat belongs to the selected flight.
7. `booking-service` checks that the seat is available.
8. `booking-service` reserves the seat through `seat-service`.
9. `booking-service` generates a booking reference and stores the booking in `booking_service_db`.
10. If persistence fails after reservation, `booking-service` attempts to release the seat to avoid leaving the seat locked.

### Booking update flow

1. Client sends `PUT /bookings/{id}`.
2. `booking-service` validates the new user, flight, and seat.
3. If the seat changes, the new seat is reserved first.
4. The booking is updated in the database.
5. The old seat is released if a different seat was selected.

### Booking deletion flow

1. Client sends `DELETE /bookings/{id}`.
2. `booking-service` deletes the booking record.
3. `booking-service` releases the reserved seat through `seat-service`.

## Search Flow

The search flow is handled by `search-service`.

1. Client sends `GET /search` with query parameters such as:
   - `source`
   - `destination`
   - `departureDate`
   - `returnDate`
   - `numberOfPassengers`
   - `travelClass`
2. `search-service` validates the request.
3. `search-service` stores the search request in `search_service_db` as `SearchHistory`.
4. `search-service` calls `flight-service` using OpenFeign.
5. `search-service` filters the returned flights based on:
   - source
   - destination
   - departure date
   - available seats
6. Matching flights are returned as `SearchResponseDto`.

### Current search limitation

`flight-service` currently does not expose `travelClass` or return-trip-specific search data, so `search-service` stores those request values but cannot yet filter on them at the flight data level. That part can be enhanced later without changing the service boundaries.

## Ticket Flow

The ticket flow is handled by `ticket-service`.

1. Client sends `POST /tickets` or `POST /tickets/generate`.
2. `ticket-service` validates the request.
3. `ticket-service` verifies the booking by calling `booking-service`.
4. If the booking exists and is not cancelled, `ticket-service` generates a unique ticket number.
5. Ticket data is stored in `ticket_service_db`.
6. Tickets can later be fetched by ID, fetched by booking ID, updated, cancelled, or deleted.

## Database Architecture

The system uses the database-per-service pattern.

| Service | Database | Purpose |
|---|---|---|
| `flight-service` | `flight_service_db` | Stores flight master data |
| `user-service` | `user_service_db` | Stores passenger/user profile data |
| `search-service` | `search_service_db` | Stores search history |
| `booking-service` | `booking_service_db` | Stores booking transactions |
| `seat-service` | `seat_service_db` | Stores seat inventory and reservation status |
| `ticket-service` | `ticket_service_db` | Stores generated tickets |

### Database characteristics

- Every microservice owns its own schema and tables.
- Services do not directly access another service's database.
- Cross-service coordination happens only through REST + OpenFeign.
- JPA/Hibernate is used with `ddl-auto=update`.
- MySQL is used as the persistence layer across all services.

## Package Architecture

Every microservice follows the same clean package structure:

```text
<service>/src/main/java/com/example/<service_name>/
├── controller/
├── service/
├── service/impl/
├── repository/
├── entity/
├── dto/
├── exception/
└── client/        # present in services that use OpenFeign
```

### Package responsibilities

- `controller/`
  Handles HTTP requests and responses only.

- `service/`
  Defines business service interfaces.

- `service/impl/`
  Contains business logic implementations.

- `repository/`
  Provides database access using `JpaRepository`.

- `entity/`
  Contains JPA entity models mapped to database tables.

- `dto/`
  Defines request and response contracts used by APIs.

- `exception/`
  Contains custom exceptions and `GlobalExceptionHandler`.

- `client/`
  Contains OpenFeign interfaces for inter-service communication.

## Responsibilities of Each Service

### `flight-service`

- Manages flight records
- Exposes CRUD APIs for flights
- Stores flight metadata such as schedule, route, airline, status, and seating counts

### `user-service`

- Manages user/passenger profiles
- Exposes CRUD APIs for users
- Stores identity and contact details such as email, phone, passport, and nationality

### `search-service`

- Accepts search requests from clients
- Stores search history
- Calls `flight-service` to retrieve flights
- Returns filtered matching flights

### `seat-service`

- Manages seat inventory per flight
- Exposes CRUD APIs for seats
- Supports seat lookup by flight
- Supports seat reservation and release

### `booking-service`

- Orchestrates the booking process
- Verifies user, flight, and seat data using Feign clients
- Reserves seats after successful validation
- Stores booking transactions and booking references

### `ticket-service`

- Generates tickets only after booking verification
- Retrieves booking details from `booking-service`
- Stores issued tickets and ticket status
- Supports cancellation and lookup by booking

## Design Decisions

### 1. Independent microservices

Each folder is treated as a separate deployable Spring Boot service. This prevents tight coupling and keeps ownership boundaries clear.

### 2. Database per service

Each service has its own MySQL database. This avoids shared-schema coupling and aligns with microservice best practices.

### 3. DTO-based API design

Entities are not exposed directly in APIs. Request and response DTOs keep the API contract stable and prevent leaking persistence details.

### 4. Layered internal architecture

Each service uses controller, service, repository, and exception layers. This keeps responsibilities separated and the codebase easier to maintain.

### 5. OpenFeign for service-to-service communication

Feign clients simplify internal HTTP communication and keep dependent service calls readable and declarative.

### 6. Service-owned business rules

Each service owns its own rules:

- `seat-service` owns seat availability state
- `booking-service` owns booking orchestration
- `search-service` owns search history
- `ticket-service` owns ticket generation

### 7. Centralized exception handling

Every service includes a `GlobalExceptionHandler` so API failures return consistent HTTP responses and structured error bodies.

### 8. Production-style CRUD foundation

All core services expose clean REST APIs first, with cross-service orchestration layered on top. This makes the system easier to test incrementally before adding more advanced features.

## Current System Summary

The current implementation already establishes the core domain split:

- Flight management
- User management
- Flight search
- Seat inventory
- Booking orchestration
- Ticket generation

This gives the project a strong base for future additions such as payment processing, API gateway routing, service discovery, authentication, notification flows, and centralized configuration.
