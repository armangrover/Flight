package com.example.search_service.exception;

import org.springframework.http.HttpStatus;

public class SearchException extends RuntimeException {

    private final HttpStatus status;

    public SearchException(String message) {
        this(HttpStatus.BAD_REQUEST, message);
    }

    public SearchException(HttpStatus status, String message) {
        super(message);
        this.status = status;
    }

    public HttpStatus getStatus() {
        return status;
    }
}
