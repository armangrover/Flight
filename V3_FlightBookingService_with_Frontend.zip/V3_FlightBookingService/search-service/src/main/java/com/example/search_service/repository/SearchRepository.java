package com.example.search_service.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.search_service.entity.SearchHistory;

public interface SearchRepository extends JpaRepository<SearchHistory, Long> {
}
