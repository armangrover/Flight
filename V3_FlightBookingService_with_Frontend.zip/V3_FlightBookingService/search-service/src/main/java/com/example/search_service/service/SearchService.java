package com.example.search_service.service;

import java.util.List;

import com.example.search_service.dto.SearchRequestDto;
import com.example.search_service.dto.SearchResponseDto;

public interface SearchService {

    List<SearchResponseDto> searchFlights(SearchRequestDto searchRequestDto);
}
