package com.example.search_service.service.impl;

import java.time.LocalDateTime;
import java.util.List;

import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

import com.example.search_service.client.FlightClient;
import com.example.search_service.dto.FlightResponseDto;
import com.example.search_service.dto.SearchRequestDto;
import com.example.search_service.dto.SearchResponseDto;
import com.example.search_service.entity.SearchHistory;
import com.example.search_service.exception.SearchException;
import com.example.search_service.repository.SearchRepository;
import com.example.search_service.service.SearchService;

import feign.FeignException;

@Service
public class SearchServiceImpl implements SearchService {

    private final SearchRepository searchRepository;
    private final FlightClient flightClient;

    public SearchServiceImpl(SearchRepository searchRepository, FlightClient flightClient) {
        this.searchRepository = searchRepository;
        this.flightClient = flightClient;
    }

    @Override
    public List<SearchResponseDto> searchFlights(SearchRequestDto searchRequestDto) {
        validateSearchRequest(searchRequestDto);
        saveSearchHistory(searchRequestDto);

        try {
            return flightClient.searchFlights(
                            searchRequestDto.getSource(),
                            searchRequestDto.getDestination(),
                            searchRequestDto.getDepartureDate(),
                            searchRequestDto.getNumberOfPassengers())
                    .stream()
                    .map(this::mapToSearchResponseDto)
                    .toList();
        } catch (FeignException exception) {
            throw new SearchException(
                    HttpStatus.SERVICE_UNAVAILABLE,
                    "Unable to fetch flights from flight-service at this time");
        }
    }

    private void validateSearchRequest(SearchRequestDto searchRequestDto) {
        if (searchRequestDto.getSource().equalsIgnoreCase(searchRequestDto.getDestination())) {
            throw new SearchException("Source and destination cannot be the same");
        }

        if (searchRequestDto.getReturnDate() != null
                && searchRequestDto.getReturnDate().isBefore(searchRequestDto.getDepartureDate())) {
            throw new SearchException("Return date cannot be before departure date");
        }
    }

    private void saveSearchHistory(SearchRequestDto searchRequestDto) {
        SearchHistory searchHistory = SearchHistory.builder()
                .source(searchRequestDto.getSource())
                .destination(searchRequestDto.getDestination())
                .departureDate(searchRequestDto.getDepartureDate())
                .returnDate(searchRequestDto.getReturnDate())
                .numberOfPassengers(searchRequestDto.getNumberOfPassengers())
                .travelClass(searchRequestDto.getTravelClass())
                .searchedAt(LocalDateTime.now())
                .build();

        searchRepository.save(searchHistory);
    }

    private SearchResponseDto mapToSearchResponseDto(FlightResponseDto flightResponseDto) {
        return SearchResponseDto.builder()
                .id(flightResponseDto.getId())
                .flightNumber(flightResponseDto.getFlightNumber())
                .airline(flightResponseDto.getAirline())
                .source(flightResponseDto.getSource())
                .destination(flightResponseDto.getDestination())
                .departureDate(flightResponseDto.getDepartureDate())
                .departureTime(flightResponseDto.getDepartureTime())
                .arrivalDate(flightResponseDto.getArrivalDate())
                .arrivalTime(flightResponseDto.getArrivalTime())
                .duration(flightResponseDto.getDuration())
                .price(flightResponseDto.getPrice())
                .availableSeats(flightResponseDto.getAvailableSeats())
                .totalSeats(flightResponseDto.getTotalSeats())
                .flightStatus(flightResponseDto.getFlightStatus())
                .aircraftType(flightResponseDto.getAircraftType())
                .terminal(flightResponseDto.getTerminal())
                .gate(flightResponseDto.getGate())
                .build();
    }
}
