package com.example.search_service.client;

import java.time.LocalDate;
import java.util.List;

import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.example.search_service.dto.FlightResponseDto;

@FeignClient(name = "flight-service-client", url = "${flight.service.url}")
public interface FlightClient {

    @GetMapping("/flights/search")
    List<FlightResponseDto> searchFlights(
            @RequestParam String source,
            @RequestParam String destination,
            @RequestParam @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate departureDate,
            @RequestParam Integer numberOfPassengers);
}
