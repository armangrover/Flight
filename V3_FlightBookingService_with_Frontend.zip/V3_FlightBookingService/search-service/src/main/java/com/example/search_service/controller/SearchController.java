package com.example.search_service.controller;

import java.util.List;

import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import com.example.search_service.dto.SearchRequestDto;
import com.example.search_service.dto.SearchResponseDto;
import com.example.search_service.service.SearchService;

import jakarta.validation.Valid;

@RestController
@RequestMapping("/search")
@Validated
@CrossOrigin(origins = "http://localhost:5173")
public class SearchController {

    private final SearchService searchService;

    public SearchController(SearchService searchService) {
        this.searchService = searchService;
    }

    @GetMapping
    public ResponseEntity<List<SearchResponseDto>> searchFlights(
            @Valid @ModelAttribute SearchRequestDto searchRequestDto) {
        return ResponseEntity.ok(searchService.searchFlights(searchRequestDto));
    }
}
