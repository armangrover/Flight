# Additional Features

This file documents the backend features added after the initial CRUD microservices were completed. Continue updating this file whenever a new integration feature is added.

## Implementation Status

| Feature | Status | Services Updated |
|---|---|---|
| JWT Authentication | Implemented | `user-service`, all protected services |
| Role Based Authorization | Implemented | All six services |
| User Profile APIs | Implemented | `user-service` |
| User Booking History | Implemented | `user-service`, `booking-service`, `flight-service`, `ticket-service` |
| Booking Cancellation | Implemented | `booking-service`, `seat-service`, `ticket-service` |
| Flight Seat Count Sync | Implemented | `seat-service`, `flight-service` |
| Ticket PDF Download | Implemented | `ticket-service`, `booking-service`, `user-service`, `flight-service` |

## New Dependencies

| Service | Dependency | Purpose |
|---|---|---|
| All services | `spring-boot-starter-security` | JWT authentication and endpoint authorization |
| `ticket-service` | `com.github.librepdf:openpdf:1.3.39` | PDF ticket generation |

Existing OpenFeign dependencies are reused for service-to-service calls.

## New Database Fields

| Service | Table | Field | Purpose |
|---|---|---|---|
| `user-service` | `users` | `role` | Stores `ROLE_USER` or `ROLE_ADMIN` authorization role |

No new tables or entities were added for these features.

## JWT Configuration

Each protected service reads the shared JWT secret from:

```properties
jwt.secret=${JWT_SECRET:flight-booking-system-development-secret-key-change-me}
```

`user-service` also supports token expiration:

```properties
jwt.expiration-ms=${JWT_EXPIRATION_MS:86400000}
```

For service-to-service calls, Feign interceptors forward the incoming `Authorization` header so downstream services can validate the same user token.

## Authentication Flow

1. Client registers through `POST /auth/register` or logs in through `POST /auth/login`.
2. `user-service` validates credentials and returns a JWT.
3. Client sends `Authorization: Bearer <token>` on protected requests.
4. Each service validates the JWT and authorizes based on `role`.

### Auth Endpoints

| Service | Method | URL | Purpose | Auth Required | Role | Request JSON | Response JSON | Status Codes |
|---|---|---|---|---|---|---|---|---|
| `user-service` | `POST` | `/auth/register` | Register user and return JWT | No | Public | `UserRequestDto` | `AuthResponseDto` | `200`, `400`, `409` |
| `user-service` | `POST` | `/auth/login` | Login and return JWT | No | Public | `LoginRequestDto` | `AuthResponseDto` | `200`, `400`, `401` |

Register request:

```json
{
  "firstName": "Aman",
  "lastName": "Sharma",
  "email": "aman.sharma@example.com",
  "phoneNumber": "9876543210",
  "password": "P@ssw0rd123",
  "dateOfBirth": "1998-04-15",
  "gender": "Male",
  "nationality": "Indian",
  "passportNumber": "N1234567",
  "address": "New Delhi, India"
}
```

Auth response:

```json
{
  "token": "eyJhbGciOiJIUzI1NiJ9...",
  "tokenType": "Bearer",
  "userId": 1,
  "email": "aman.sharma@example.com",
  "role": "ROLE_USER"
}
```

## User Profile And Booking History

Users can fetch and update their own profile using the JWT subject email. Booking history is assembled by `user-service` using Feign calls to booking, flight, and ticket services.

| Service | Method | URL | Purpose | Auth Required | Role | Request JSON | Response JSON | Status Codes |
|---|---|---|---|---|---|---|---|---|
| `user-service` | `GET` | `/users/me` | View current user profile | Yes | `ROLE_USER` | None | `UserResponseDto` | `200`, `401`, `403`, `404` |
| `user-service` | `PUT` | `/users/me` | Update current user profile | Yes | `ROLE_USER` | `UserRequestDto` | `UserResponseDto` | `200`, `400`, `401`, `403`, `404` |
| `user-service` | `GET` | `/users/me/bookings` | View booking history with flight, seat, and ticket info | Yes | `ROLE_USER` | None | `List<UserBookingHistoryDto>` | `200`, `401`, `403` |
| `booking-service` | `GET` | `/bookings/user/{userId}` | Return bookings for one user | Yes | `ROLE_USER`, `ROLE_ADMIN` | None | `List<BookingResponseDto>` | `200`, `401`, `403` |

Booking history response example:

```json
[
  {
    "booking": {
      "id": 1,
      "bookingReference": "BKG-1A2B3C4D5E",
      "userId": 1,
      "flightId": 1,
      "seatId": 10,
      "seatNumber": "12A",
      "bookingDate": "2026-07-21T10:30:00",
      "bookingStatus": "CONFIRMED",
      "paymentStatus": "PAID",
      "totalFare": 6500.00
    },
    "flight": {
      "id": 1,
      "flightNumber": "AI101",
      "airline": "Air India",
      "source": "Delhi",
      "destination": "Mumbai"
    },
    "ticket": {
      "id": 1,
      "ticketNumber": "TKT-1A2B3C4D5E",
      "bookingId": 1,
      "ticketStatus": "ISSUED"
    }
  }
]
```

## Booking Cancellation Flow

Cancellation does not physically delete bookings. It updates the booking status and coordinates other services.

1. Client calls `PUT /bookings/{id}/cancel`.
2. `booking-service` sets `bookingStatus` to `CANCELLED`.
3. `booking-service` calls `seat-service` to release the seat.
4. `seat-service` calls `flight-service` to increase available seats.
5. `booking-service` calls `ticket-service` to cancel the ticket by booking ID if a ticket exists.

| Service | Method | URL | Purpose | Auth Required | Role | Request JSON | Response JSON | Status Codes |
|---|---|---|---|---|---|---|---|---|
| `booking-service` | `PUT` | `/bookings/{id}/cancel` | Cancel booking without deleting it | Yes | `ROLE_USER`, `ROLE_ADMIN` | None | `BookingResponseDto` | `200`, `401`, `403`, `404` |
| `booking-service` | `DELETE` | `/bookings/{id}` | Compatibility endpoint that now performs cancellation | Yes | `ROLE_USER`, `ROLE_ADMIN` | None | None | `204`, `401`, `403`, `404` |
| `ticket-service` | `PUT` | `/tickets/booking/{bookingId}/cancel` | Cancel ticket by booking ID | Yes | `ROLE_USER`, `ROLE_ADMIN` | None | `TicketResponseDto` | `200`, `401`, `403`, `404` |

Cancelled booking response example:

```json
{
  "id": 1,
  "bookingReference": "BKG-1A2B3C4D5E",
  "userId": 1,
  "flightId": 1,
  "seatId": 10,
  "seatNumber": "12A",
  "bookingDate": "2026-07-21T10:30:00",
  "bookingStatus": "CANCELLED",
  "paymentStatus": "PAID",
  "totalFare": 6500.00
}
```

## Flight Seat Count Sync

Seat availability is synchronized from `seat-service`, because every reservation/release should update flight availability regardless of whether the request came from booking-service or a direct API call.

| Service | Method | URL | Purpose | Auth Required | Role | Request JSON | Response JSON | Status Codes |
|---|---|---|---|---|---|---|---|---|
| `seat-service` | `PUT` | `/seats/{id}/reserve` | Reserve seat and decrease flight availability | Yes | `ROLE_USER`, `ROLE_ADMIN` | None | `SeatResponseDto` | `200`, `400`, `401`, `403`, `404` |
| `seat-service` | `PUT` | `/seats/{id}/release` | Release seat and increase flight availability | Yes | `ROLE_USER`, `ROLE_ADMIN` | None | `SeatResponseDto` | `200`, `400`, `401`, `403`, `404` |
| `flight-service` | `PUT` | `/flights/{id}/decrease-available-seats` | Decrease available seats by one | Yes | `ROLE_USER`, `ROLE_ADMIN` | None | `FlightResponseDto` | `200`, `400`, `401`, `403`, `404` |
| `flight-service` | `PUT` | `/flights/{id}/increase-available-seats` | Increase available seats by one | Yes | `ROLE_USER`, `ROLE_ADMIN` | None | `FlightResponseDto` | `200`, `400`, `401`, `403`, `404` |

## Ticket PDF Flow

Ticket PDFs are generated by `ticket-service` using OpenPDF.

1. Client generates a ticket using `POST /tickets/generate`.
2. Client downloads the ticket using `GET /tickets/{ticketId}/download`.
3. `ticket-service` fetches booking details from `booking-service`.
4. `ticket-service` fetches passenger details from `user-service`.
5. `ticket-service` fetches flight details from `flight-service`.
6. PDF bytes are returned with `Content-Type: application/pdf`.

| Service | Method | URL | Purpose | Auth Required | Role | Request JSON | Response JSON | Status Codes |
|---|---|---|---|---|---|---|---|---|
| `ticket-service` | `GET` | `/tickets/{id}/download` | Download a ticket PDF | Yes | `ROLE_USER`, `ROLE_ADMIN` | None | PDF bytes | `200`, `401`, `403`, `404`, `503` |

PDF contains:

| Field |
|---|
| Passenger Name |
| Booking ID |
| Ticket ID |
| Ticket Number |
| Flight Number |
| Airline |
| Source |
| Destination |
| Departure Date |
| Departure Time |
| Arrival Date |
| Arrival Time |
| Seat Number |
| Terminal |
| Gate |
| Booking Status |
| Ticket Status |
| Fare |
| Generation Date |

## Frontend Integration Notes

Use this backend workflow from a frontend:

1. Call `POST /auth/register` or `POST /auth/login`.
2. Store the returned JWT.
3. Add `Authorization: Bearer <token>` to protected API requests.
4. Search flights using public `GET /search`.
5. Load seats using protected `GET /seats/flight/{flightId}`.
6. Create booking using `POST /bookings`.
7. Generate ticket using `POST /tickets/generate`.
8. Download ticket PDF using `GET /tickets/{ticketId}/download`.
9. Cancel booking using `PUT /bookings/{bookingId}/cancel`.

Admin-only frontend screens should use an account with `ROLE_ADMIN` for flight CRUD, seat CRUD, user list, and all bookings.

## Manual Configuration Notes

- Existing users created before BCrypt was added may have plain-text passwords and may not login. Recreate them through `/auth/register` or update the database with BCrypt-hashed passwords.
- New registrations always receive `ROLE_USER`.
- To create an admin account for testing, update a trusted user record manually in MySQL:

```sql
UPDATE users SET role = 'ROLE_ADMIN' WHERE email = 'admin@example.com';
```

- All services must share the same `JWT_SECRET` value.
- Start services on ports `8081`, `8082`, `8083`, `8084`, `8085`, and `8086`.

## Verification Checklist

Use this checklist after starting all services:

| Step | Expected Result |
|---|---|
| Register user | JWT returned with `ROLE_USER` |
| Login user | JWT returned |
| Search flights | Public search returns matching flights |
| Get seats for flight | Requires JWT and returns seats |
| Create booking | User, flight, and seat verified; seat becomes `RESERVED`; flight available seats decreases |
| Generate ticket | Ticket created using booking data |
| Download ticket PDF | PDF file returned with passenger, booking, flight, and seat details |
| Get `/users/me/bookings` | Booking history includes booking, flight, seat number, and ticket details |
| Cancel booking | Booking becomes `CANCELLED`; seat becomes `AVAILABLE`; flight available seats increases; ticket becomes `CANCELLED` |
