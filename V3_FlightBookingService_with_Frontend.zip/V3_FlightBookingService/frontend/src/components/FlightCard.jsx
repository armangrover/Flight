import { formatMoney } from '../utils/format'

export function FlightCard({ flight, selected, onSelect }) {
  return (
    <article className={selected ? 'flight-card selected' : 'flight-card'}>
      <div>
        <strong>{flight.airline}</strong>
        <span>{flight.flightNumber}</span>
      </div>
      <div className="route-line">
        <b>{flight.source}</b>
        <span>
          {flight.departureTime?.slice(0, 5)} - {flight.arrivalTime?.slice(0, 5)}
        </span>
        <b>{flight.destination}</b>
      </div>
      <div className="flight-meta">
        <span>{flight.duration}</span>
        <span>{flight.aircraftType}</span>
        <span>{flight.availableSeats} seats</span>
        <strong>{formatMoney(flight.price)}</strong>
      </div>
      <button type="button" onClick={() => onSelect(flight)}>
        Select
      </button>
    </article>
  )
}
