export function Field({ label, ...props }) {
  return (
    <label>
      <span>{label}</span>
      <input {...props} required={props.required ?? props.name !== 'returnDate'} />
    </label>
  )
}

export function Select({ label, options, ...props }) {
  const normalized = options.map((option) =>
    typeof option === 'string' ? { label: option, value: option } : option,
  )

  return (
    <label>
      <span>{label}</span>
      <select {...props} required>
        <option value="">Select</option>
        {normalized.map((option) => (
          <option key={option.value} value={option.value}>
            {option.label}
          </option>
        ))}
      </select>
    </label>
  )
}
