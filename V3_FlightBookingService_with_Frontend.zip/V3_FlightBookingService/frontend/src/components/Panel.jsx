export function Panel({ title, children }) {
  return (
    <section className="service-panel">
      <h2>{title}</h2>
      {children}
    </section>
  )
}
