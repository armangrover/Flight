export function ToastStack({ toasts, onDismiss }) {
  return (
    <div className="toast-stack" aria-live="polite" aria-relevant="additions removals">
      {toasts.map((toast) => (
        <div className={`toast ${toast.type}`} key={toast.id} role="status">
          <div>
            <strong>{toast.type === 'error' ? 'Backend error' : 'Success'}</strong>
            <span>{toast.message}</span>
          </div>
          <button type="button" onClick={() => onDismiss(toast.id)} aria-label="Dismiss toast">
            x
          </button>
        </div>
      ))}
    </div>
  )
}
