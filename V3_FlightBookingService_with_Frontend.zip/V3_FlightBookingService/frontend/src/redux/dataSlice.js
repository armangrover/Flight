import { createSlice } from '@reduxjs/toolkit'

const dataSlice = createSlice({
  name: 'data',
  initialState: { flights: [], users: [], seats: [], bookings: [], tickets: [] },
  reducers: { setData: (state, action) => Object.assign(state, action.payload) },
})
export const { setData } = dataSlice.actions
export default dataSlice.reducer
