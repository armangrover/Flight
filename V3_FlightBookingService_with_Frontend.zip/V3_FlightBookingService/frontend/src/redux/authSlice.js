import { createSlice } from '@reduxjs/toolkit'

const saved = JSON.parse(localStorage.getItem('aeroswift.session') || 'null')
const initialState = { token: saved?.token || '', user: saved?.user || null, initialized: true }

const authSlice = createSlice({
  name: 'auth', initialState,
  reducers: {
    setSession(state, action) {
      state.token = action.payload.token
      state.user = { ...action.payload.user, id: action.payload.user.id ?? action.payload.user.userId }
      localStorage.setItem('aeroswift.token', state.token)
      localStorage.setItem('aeroswift.session', JSON.stringify({ ...action.payload, user: state.user }))
    },
    logout(state) { state.token = ''; state.user = null; localStorage.removeItem('aeroswift.token'); localStorage.removeItem('aeroswift.session') },
  },
})
export const { setSession, logout } = authSlice.actions
export default authSlice.reducer
