export { authApi as default, authApi } from '../api'
