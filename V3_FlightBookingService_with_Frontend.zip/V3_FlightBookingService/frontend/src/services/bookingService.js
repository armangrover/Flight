export { bookingApi as default, bookingApi } from '../api'
