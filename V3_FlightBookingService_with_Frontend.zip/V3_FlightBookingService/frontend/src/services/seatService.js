export { seatApi as default, seatApi } from '../api'
