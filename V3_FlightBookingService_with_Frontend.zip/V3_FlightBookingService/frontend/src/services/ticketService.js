export { ticketApi as default, ticketApi } from '../api'
