export { flightApi as default, flightApi } from '../api'
