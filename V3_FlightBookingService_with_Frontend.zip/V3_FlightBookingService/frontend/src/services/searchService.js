export { searchApi as default, searchApi } from '../api'
