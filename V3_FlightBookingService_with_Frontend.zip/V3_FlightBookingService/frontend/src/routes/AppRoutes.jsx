import { Navigate, Outlet, Route, Routes, useLocation } from 'react-router-dom'
import { useSelector } from 'react-redux'
import { BookingPage } from '../pages/BookingPage'
import { ManagementPage } from '../pages/ManagementPage'
import { LoginPage } from '../pages/LoginPage'
import { RegisterPage } from '../pages/RegisterPage'
import { ProfilePage } from '../pages/ProfilePage'
import { BookingHistoryPage } from '../pages/BookingHistoryPage'

export function ProtectedRoute() {
  const token = useSelector((state) => state.auth.token); 
  const location = useLocation()
  return token ? <Outlet /> : <Navigate to={`/login?from=${encodeURIComponent(location.pathname)}`} replace />
}


export function AdminRoute() {
  const role = useSelector((state) => state.auth.user?.role)
  return role === 'ROLE_ADMIN' || role === 'ADMIN' ? <Outlet /> : <Navigate to="/" replace />
}

function NotFound() { return <section className="empty-page"><h2>Page not found</h2><p>That AeroSwift page does not exist.</p></section> }


export function AppRoutes(props) { return( 
  <Routes>
    <Route path="/login" element={<LoginPage />} />
    <Route path="/register" element={<RegisterPage />} />
    <Route element={<ProtectedRoute />}><Route path="/" element={<BookingPage {...props} />} />
    <Route path="/booking" element={<BookingPage {...props} />} />
    <Route path="/profile" element={<ProfilePage />} />
    <Route path="/bookings" element={<BookingHistoryPage />} />
    <Route path="/my-bookings" element={<BookingHistoryPage />} />
    <Route path="/mybooking" element={<BookingHistoryPage />} />
    <Route element={<AdminRoute />}><Route path="/manage/*" element={<ManagementPage {...props} />} />
    </Route>
    </Route>
    <Route path="*" element={<NotFound />} />
  </Routes> 
)}
