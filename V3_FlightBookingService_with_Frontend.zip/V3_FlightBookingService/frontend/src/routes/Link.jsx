import { NavLink } from 'react-router-dom'

export function Link({ href, label }) { 
    return (
    <NavLink className={({ isActive }) => isActive ? 'active' : ''} to={href}>
        {label}
    </NavLink> 
)
}
