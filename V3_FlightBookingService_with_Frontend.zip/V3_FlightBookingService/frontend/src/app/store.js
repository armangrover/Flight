import { configureStore } from '@reduxjs/toolkit'
import auth from '../redux/authSlice'
import data from '../redux/dataSlice'

export const store = configureStore({ reducer: { auth, data } })
