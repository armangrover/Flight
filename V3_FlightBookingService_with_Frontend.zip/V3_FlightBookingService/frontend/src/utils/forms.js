import { today } from './date'

export const emptyFlight = {
  flightNumber: '',
  airline: '',
  source: '',
  destination: '',
  departureDate: today,
  departureTime: '09:30:00',
  arrivalDate: today,
  arrivalTime: '11:45:00',
  duration: '2h 15m',
  price: 6500,
  availableSeats: 120,
  totalSeats: 180,
  flightStatus: 'SCHEDULED',
  aircraftType: 'Boeing 737',
  terminal: 'T2',
  gate: 'A12',
}

export const emptyUser = {
  firstName: '',
  lastName: '',
  email: '',
  phoneNumber: '',
  password: '',
  dateOfBirth: '1998-04-15',
  gender: 'Male',
  nationality: 'Indian',
  passportNumber: '',
  address: '',
}

export const emptySeat = {
  flightId: '',
  seatNumber: '',
  seatType: 'Window',
  seatClass: 'Economy',
  price: 6500,
  status: 'AVAILABLE',
}

export const emptyBookingEdit = {
  id: '',
  userId: '',
  flightId: '',
  seatId: '',
  bookingStatus: 'CONFIRMED',
  paymentStatus: 'PAID',
  totalFare: 0,
}

export const emptyTicketEdit = {
  id: '',
  bookingId: '',
  ticketStatus: 'ISSUED',
}
