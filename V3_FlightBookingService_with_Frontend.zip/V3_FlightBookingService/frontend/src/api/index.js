import { queryString, request } from './client'

const post = (data) => ({ method: 'POST', data })
const put = (data) => ({ method: 'PUT', data })

export const authApi = {
  login: (data) => request('users', '/auth/login', post(data)),
  register: (data) => request('users', '/auth/register', post(data)),
}

export const searchApi = { searchFlights: (params) => request('search', `/search?${queryString(params)}`) }
export const flightApi = {
  list: () => request('flights', '/flights'), get: (id) => request('flights', `/flights/${id}`),
  search: (params) => request('flights', `/flights/search?${queryString(params)}`),
  create: (data) => request('flights', '/flights', post(data)), update: (id, data) => request('flights', `/flights/${id}`, put(data)),
  remove: (id) => request('flights', `/flights/${id}`, { method: 'DELETE' }),
  decreaseAvailableSeats: (id) => request('flights', `/flights/${id}/decrease-available-seats`, put()),
  increaseAvailableSeats: (id) => request('flights', `/flights/${id}/increase-available-seats`, put()),
}
export const userApi = {
  list: () => request('users', '/users'), get: (id) => request('users', `/users/${id}`),
  me: () => request('users', '/users/me'), history: () => request('users', '/users/me/bookings'),
  updateMe: (data) => request('users', '/users/me', put(data)),
  create: (data) => request('users', '/users', post(data)), update: (id, data) => request('users', `/users/${id}`, put(data)),
  remove: (id) => request('users', `/users/${id}`, { method: 'DELETE' }),
}
export const seatApi = {
  list: () => request('seats', '/seats'), get: (id) => request('seats', `/seats/${id}`), byFlight: (id) => request('seats', `/seats/flight/${id}`),
  create: (data) => request('seats', '/seats', post(data)), update: (id, data) => request('seats', `/seats/${id}`, put(data)),
  reserve: (id) => request('seats', `/seats/${id}/reserve`, put()), release: (id) => request('seats', `/seats/${id}/release`, put()),
  remove: (id) => request('seats', `/seats/${id}`, { method: 'DELETE' }),
}
export const bookingApi = {
  list: () => request('bookings', '/bookings'), get: (id) => request('bookings', `/bookings/${id}`), byUser: (id) => request('bookings', `/bookings/user/${id}`),
  create: (data) => request('bookings', '/bookings', post(data)), update: (id, data) => request('bookings', `/bookings/${id}`, put(data)),
  cancel: (id) => request('bookings', `/bookings/${id}/cancel`, put()),
  remove: (id) => request('bookings', `/bookings/${id}`, { method: 'DELETE' }),
}
export const ticketApi = {
  list: () => request('tickets', '/tickets'), get: (id) => request('tickets', `/tickets/${id}`), byBooking: (id) => request('tickets', `/tickets/booking/${id}`),
  create: (data) => request('tickets', '/tickets', post(data)), generate: (data) => request('tickets', '/tickets/generate', post(data)),
  update: (id, data) => request('tickets', `/tickets/${id}`, put(data)), cancel: (id) => request('tickets', `/tickets/${id}/cancel`, put()), cancelByBooking: (id) => request('tickets', `/tickets/booking/${id}/cancel`, put()),
  download: (id) => request('tickets', `/tickets/${id}/download`, { responseType: 'blob' }),
  remove: (id) => request('tickets', `/tickets/${id}`, { method: 'DELETE' }),
}
export const apiByResource = { flights: flightApi, users: userApi, seats: seatApi, bookings: bookingApi, tickets: ticketApi }
