import axios from 'axios'

export const API_BASE_URLS = {
  flights: import.meta.env.VITE_FLIGHT_API_URL || 'http://localhost:8081',
  users: import.meta.env.VITE_USER_API_URL || 'http://localhost:8082',
  search: import.meta.env.VITE_SEARCH_API_URL || 'http://localhost:8083',
  bookings: import.meta.env.VITE_BOOKING_API_URL || 'http://localhost:8084',
  seats: import.meta.env.VITE_SEAT_API_URL || 'http://localhost:8085',
  tickets: import.meta.env.VITE_TICKET_API_URL || 'http://localhost:8086',
}

// One transport for every backend service. The service base URL is selected per request.
export const apiClient = axios.create({ headers: { 'Content-Type': 'application/json' } })

apiClient.interceptors.request.use((config) => {
  const token = localStorage.getItem('aeroswift.token')
  if (token) config.headers.Authorization = `Bearer ${token}`
  return config
})

apiClient.interceptors.response.use(
  (response) => response,
  (error) => {
    if (error.response?.status === 401) {
      localStorage.removeItem('aeroswift.session')
      localStorage.removeItem('aeroswift.token')
    }
    const payload = error.response?.data
    const fieldErrors = payload?.errors
      ? Object.entries(payload.errors).map(([field, value]) => `${field}: ${value}`)
      : []
    const message = [payload?.message || payload?.error || error.message, ...fieldErrors].join(' | ')
    return Promise.reject(new Error(message || `Request failed with status ${error.response?.status}`))
  },
)

export function request(service, path, config = {}) {
  return apiClient({ baseURL: API_BASE_URLS[service], url: path, ...config }).then(({ data }) => data)
}

export function queryString(params) {
  return new URLSearchParams(params).toString()
}
