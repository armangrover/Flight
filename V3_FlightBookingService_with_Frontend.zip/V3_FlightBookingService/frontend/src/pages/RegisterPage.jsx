import { useState } from 'react'
import { useDispatch } from 'react-redux'
import { Link, useNavigate } from 'react-router-dom'
import { authApi } from '../api'
import { setSession } from '../redux/authSlice'
import { Field } from '../components/FormControls'
import { AuthShell } from './LoginPage'
const fields = ['firstName', 'lastName', 'email', 'phoneNumber', 'dateOfBirth', 'gender', 'nationality', 'passportNumber', 'address', 'password']
export function RegisterPage() {
  const dispatch = useDispatch(); 
  const navigate = useNavigate(); 
  const [form, setForm] = useState(Object.fromEntries(fields.map((field) => [field, ''])));
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);
  const submit = async (event) => { 
    event.preventDefault();
    setLoading(true); 
    setError(''); 
    try {
       const session = await authApi.register(form); 
       dispatch(setSession({ token: session.token, user: session })); 
       navigate('/', { replace: true }) 
    } catch (e) { setError(e.message) } 
    finally { setLoading(false) } 
  }
  return  (
    <AuthShell title="Create your account" subtitle="Book flights and keep every ticket in one place.">
      <form className="auth-form" onSubmit={submit}>
        {fields.map((field) => <Field key={field} label={field.replace(/([A-Z])/g, ' $1')} name={field} type={field === 'dateOfBirth' ? 'date' : field === 'email' ? 'email' : field === 'password' ? 'password' : 'text'} value={form[field]} onChange={(e) => setForm({ ...form, [field]: e.target.value })} />)}
          <button className="primary-btn" disabled={loading}>
            {loading ? 'Creating…' : 'Create account'}
          </button>{error && (
            <p className="notice error">{error}</p>)
            }
      </form>
      <p className="auth-link">Already registered? <Link to="/login">Sign in</Link></p>
    </AuthShell>)
}
