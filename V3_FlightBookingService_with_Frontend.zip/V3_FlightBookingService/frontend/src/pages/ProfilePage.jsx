import { useEffect, useState } from 'react'
import { userApi } from '../api'
import { Field } from '../components/FormControls'
import { Panel } from '../components/Panel'

const profileFields = ['firstName', 'lastName', 'email', 'phoneNumber', 'dateOfBirth', 'gender', 'nationality', 'passportNumber', 'address']
export function ProfilePage() {
  const [form, setForm] = useState({}); const [loading, setLoading] = useState(true); const [message, setMessage] = useState(''); const [error, setError] = useState('')
  useEffect(() => { userApi.me().then(setForm).catch((e) => setError(e.message)).finally(() => setLoading(false)) }, [])
  const submit = async (event) => { event.preventDefault(); setLoading(true); setMessage(''); setError(''); try { setForm(await userApi.updateMe({ ...form, password: form.password || undefined })); setMessage('Profile updated.') } catch (e) { setError(e.message) } finally { setLoading(false) } }
  return <div className="account-page"><Panel title="My profile"><p className="compact">View and update the profile used for your bookings.</p><form className="profile-form" onSubmit={submit}>{profileFields.map((field) => <Field key={field} label={field.replace(/([A-Z])/g, ' $1')} name={field} type={field === 'dateOfBirth' ? 'date' : field === 'email' ? 'email' : 'text'} value={form[field] || ''} onChange={(e) => setForm({ ...form, [field]: e.target.value })} />)}<Field label="New password (optional)" name="password" type="password" required={false} value={form.password || ''} onChange={(e) => setForm({ ...form, password: e.target.value })} /><button className="primary-btn" disabled={loading}>{loading ? 'Saving…' : 'Save profile'}</button></form>{message && <p className="success-message">{message}</p>}{error && <p className="notice error">{error}</p>}</Panel></div>
}
