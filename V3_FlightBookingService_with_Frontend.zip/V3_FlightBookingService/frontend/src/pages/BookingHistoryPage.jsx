import { useEffect, useState } from 'react'
import { bookingApi, ticketApi, userApi } from '../api'
import { Panel } from '../components/Panel'
import { formatMoney } from '../utils/format'

export function BookingHistoryPage() {
  const [history, setHistory] = useState([]); const [loading, setLoading] = useState(true); const [error, setError] = useState('')
  const load = () => { setLoading(true); userApi.history().then(setHistory).catch((e) => setError(e.message)).finally(() => setLoading(false)) }
  useEffect(() => { userApi.history().then(setHistory).catch((e) => setError(e.message)).finally(() => setLoading(false)) }, [])
  const cancel = async (id) => { try { await bookingApi.cancel(id); load() } catch (e) { setError(e.message) } }
  const download = async (ticket) => { try { const blob = await ticketApi.download(ticket.id); const url = URL.createObjectURL(blob); const anchor = document.createElement('a'); anchor.href = url; anchor.download = `${ticket.ticketNumber || `ticket-${ticket.id}`}.pdf`; anchor.click(); URL.revokeObjectURL(url) } catch (e) { setError(e.message) } }
  return <div className="history-page"><Panel title="Booking history"><p className="compact">Your bookings, flight details, seats, and tickets.</p>{loading && <p className="compact">Loading history…</p>}{error && <p className="notice error">{error}</p>}{!loading && !history.length && <p className="compact">No bookings yet.</p>}<div className="history-list">{history.map((item) => { const booking = item.booking || item; const flight = item.flight || {}; const ticket = item.ticket; return <article className="history-card" key={booking.id}><div><strong>{booking.bookingReference || `Booking ${booking.id}`}</strong><span>{flight.airline || 'Flight'} · {flight.flightNumber || `#${booking.flightId}`}</span><span>{flight.source || '—'} → {flight.destination || '—'} · Seat {booking.seatNumber || '—'}</span></div><div><b>{booking.bookingStatus}</b><span>{formatMoney(booking.totalFare)}</span><div className="row-actions">{booking.bookingStatus !== 'CANCELLED' && <button type="button" onClick={() => cancel(booking.id)}>Cancel booking</button>}{ticket && <button type="button" onClick={() => download(ticket)}>Download PDF</button>}</div></div></article> })}</div></Panel></div>
}
