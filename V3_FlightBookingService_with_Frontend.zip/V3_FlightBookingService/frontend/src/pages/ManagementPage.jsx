import { useState } from 'react'
import { apiByResource, bookingApi, flightApi, seatApi, ticketApi, userApi } from '../api'
import { Field, Select } from '../components/FormControls'
import { MiniList } from '../components/MiniList'
import { Panel } from '../components/Panel'
import { today } from '../utils/date'
import { emptyBookingEdit, emptyFlight, emptySeat, emptyTicketEdit, emptyUser } from '../utils/forms'
import { formatMoney, labelize } from '../utils/format'
import { normalizeBooking, normalizeFlight, normalizeSeat } from '../utils/normalizers'

export function ManagementPage({ data, refreshData, setLoading, setNotice, showToast }) {
  const [flightForm, setFlightForm] = useState(emptyFlight)
  const [userForm, setUserForm] = useState(emptyUser)
  const [seatForm, setSeatForm] = useState(emptySeat)
  const [bookingEdit, setBookingEdit] = useState(emptyBookingEdit)
  const [ticketEdit, setTicketEdit] = useState(emptyTicketEdit)
  const [apiTools, setApiTools] = useState({
    lookupService: 'flights',
    lookupId: '',
    lookupResult: null,
    flightSearchSource: 'Delhi',
    flightSearchDestination: 'Mumbai',
    flightSearchDate: today,
    flightSearchPassengers: 1,
    flightSearchResult: null,
    ticketBookingId: '',
    ticketLookupResult: null,
    directTicketBookingId: '',
    directTicketResult: null,
    bookingsUserId: '',
    bookingsByUserResult: null,
    syncFlightId: '',
  })

  const setField = (setter) => (event) => {
    const { name, value } = event.target
    setter((current) => ({ ...current, [name]: value }))
  }

  const success = (message) => {
    setNotice(message)
    showToast(message, 'success')
  }

  const fail = (error) => {
    setNotice(error.message)
    showToast(error.message, 'error')
  }

  const run = async (action, successMessage) => {
    setLoading(true)
    try {
      await action()
      success(successMessage)
      await refreshData()
    } catch (error) {
      fail(error)
    } finally {
      setLoading(false)
    }
  }

  const saveFlight = (event) => {
    event.preventDefault()
    return run(async () => {
      if (flightForm.id) await flightApi.update(flightForm.id, normalizeFlight(flightForm))
      else await flightApi.create(normalizeFlight(flightForm))
      setFlightForm(emptyFlight)
    }, 'Flight saved.')
  }

  const saveUser = (event) => {
    event.preventDefault()
    return run(async () => {
      if (userForm.id) await userApi.update(userForm.id, userForm)
      else await userApi.create(userForm)
      setUserForm(emptyUser)
    }, 'User saved.')
  }

  const saveSeat = (event) => {
    event.preventDefault()
    return run(async () => {
      if (seatForm.id) await seatApi.update(seatForm.id, normalizeSeat(seatForm))
      else await seatApi.create(normalizeSeat(seatForm))
      setSeatForm(emptySeat)
    }, 'Seat saved.')
  }

  const updateBooking = (event) => {
    event.preventDefault()
    return run(
      () => bookingApi.update(bookingEdit.id, normalizeBooking(bookingEdit)),
      'Booking updated.',
    )
  }

  const updateTicket = (event) => {
    event.preventDefault()
    return run(
      () => ticketApi.update(ticketEdit.id, {
        bookingId: Number(ticketEdit.bookingId),
        ticketStatus: ticketEdit.ticketStatus,
      }),
      'Ticket updated.',
    )
  }

  const remove = (resource, id) =>
    run(() => apiByResource[resource].remove(id), `${resource.slice(0, -1)} deleted.`)

  const reserveOrRelease = (seat) =>
    run(
      () => (seat.status === 'AVAILABLE' ? seatApi.reserve(seat.id) : seatApi.release(seat.id)),
      'Seat status changed.',
    )

  const cancelTicket = (id) => run(() => ticketApi.cancel(id), 'Ticket cancelled.')

  const lookupRecord = async (event) => {
    event.preventDefault()
    setLoading(true)
    try {
      const result = await apiByResource[apiTools.lookupService].get(apiTools.lookupId)
      setApiTools((current) => ({ ...current, lookupResult: result }))
      success('Record loaded by ID.')
    } catch (error) {
      fail(error)
    } finally {
      setLoading(false)
    }
  }

  const runFlightServiceSearch = async (event) => {
    event.preventDefault()
    setLoading(true)
    try {
      const result = await flightApi.search({
        source: apiTools.flightSearchSource,
        destination: apiTools.flightSearchDestination,
        departureDate: apiTools.flightSearchDate,
        numberOfPassengers: apiTools.flightSearchPassengers,
      })
      setApiTools((current) => ({ ...current, flightSearchResult: result }))
      success('Direct flight-service search complete.')
    } catch (error) {
      fail(error)
    } finally {
      setLoading(false)
    }
  }

  const lookupTicketByBooking = async (event) => {
    event.preventDefault()
    setLoading(true)
    try {
      const result = await ticketApi.byBooking(apiTools.ticketBookingId)
      setApiTools((current) => ({ ...current, ticketLookupResult: result }))
      success('Ticket loaded by booking ID.')
    } catch (error) {
      fail(error)
    } finally {
      setLoading(false)
    }
  }

  const createTicketDirect = (event) => {
    event.preventDefault()
    return run(async () => {
      const result = await ticketApi.create({
        bookingId: Number(apiTools.directTicketBookingId),
        ticketStatus: 'ISSUED',
      })
      setApiTools((current) => ({ ...current, directTicketResult: result }))
    }, 'Ticket generated through POST /tickets.')
  }

  const lookupBookingsByUser = async (event) => {
    event.preventDefault(); setLoading(true)
    try { const result = await bookingApi.byUser(apiTools.bookingsUserId); setApiTools((current) => ({ ...current, bookingsByUserResult: result })); success('User bookings loaded.') } catch (error) { fail(error) } finally { setLoading(false) }
  }

  const cancelTicketByBooking = (event) => {
    event.preventDefault(); return run(() => ticketApi.cancelByBooking(apiTools.ticketBookingId), 'Ticket cancelled by booking ID.')
  }

  const syncFlightSeats = (direction) => run(() => direction === 'decrease' ? flightApi.decreaseAvailableSeats(apiTools.syncFlightId) : flightApi.increaseAvailableSeats(apiTools.syncFlightId), `Flight availability ${direction}d.`)

  return (
    <div className="management-grid">
      <Panel title="API tools">
        <form onSubmit={lookupRecord}>
          <Select label="Service" name="lookupService" value={apiTools.lookupService} onChange={setField(setApiTools)} options={['flights', 'users', 'seats', 'bookings', 'tickets']} />
          <Field label="Record ID" name="lookupId" type="number" value={apiTools.lookupId} onChange={setField(setApiTools)} />
          <button className="primary-btn" type="submit">Load by ID</button>
        </form>
        <form onSubmit={runFlightServiceSearch}>
          <Field label="From" name="flightSearchSource" value={apiTools.flightSearchSource} onChange={setField(setApiTools)} />
          <Field label="To" name="flightSearchDestination" value={apiTools.flightSearchDestination} onChange={setField(setApiTools)} />
          <Field label="Date" name="flightSearchDate" type="date" value={apiTools.flightSearchDate} onChange={setField(setApiTools)} />
          <Field label="Passengers" name="flightSearchPassengers" type="number" min="1" value={apiTools.flightSearchPassengers} onChange={setField(setApiTools)} />
          <button className="primary-btn" type="submit">Search flight-service</button>
        </form>
        <form onSubmit={lookupTicketByBooking}>
          <Field label="Booking ID" name="ticketBookingId" type="number" value={apiTools.ticketBookingId} onChange={setField(setApiTools)} />
          <button className="primary-btn" type="submit">Find ticket by booking</button>
        </form>
        <form onSubmit={createTicketDirect}>
          <Field label="Booking ID" name="directTicketBookingId" type="number" value={apiTools.directTicketBookingId} onChange={setField(setApiTools)} />
          <button className="primary-btn" type="submit">POST /tickets</button>
        </form>
        <form onSubmit={lookupBookingsByUser}>
          <Field label="User ID" name="bookingsUserId" type="number" value={apiTools.bookingsUserId} onChange={setField(setApiTools)} />
          <button className="primary-btn" type="submit">Bookings by user</button>
        </form>
        <form onSubmit={(event) => event.preventDefault()}>
          <Field label="Flight ID" name="syncFlightId" type="number" value={apiTools.syncFlightId} onChange={setField(setApiTools)} />
          <div className="row-actions"><button type="button" onClick={() => syncFlightSeats('decrease')}>Decrease seats</button><button type="button" onClick={() => syncFlightSeats('increase')}>Increase seats</button></div>
        </form>
        <form onSubmit={cancelTicketByBooking}>
          <Field label="Booking ID" name="ticketBookingId" type="number" value={apiTools.ticketBookingId} onChange={setField(setApiTools)} />
          <button className="primary-btn" type="submit">Cancel ticket by booking</button>
        </form>
        <ApiToolResults apiTools={apiTools} />
      </Panel>

      <Panel title="Flights">
        <form onSubmit={saveFlight}>
          {['flightNumber', 'airline', 'source', 'destination', 'departureDate', 'departureTime', 'arrivalDate', 'arrivalTime', 'duration', 'price', 'availableSeats', 'totalSeats', 'aircraftType', 'terminal', 'gate'].map((field) => (
            <Field key={field} label={labelize(field)} name={field} type={field.includes('Date') ? 'date' : field.includes('Time') ? 'time' : ['price', 'availableSeats', 'totalSeats'].includes(field) ? 'number' : 'text'} step="1" value={flightForm[field]} onChange={setField(setFlightForm)} />
          ))}
          <Select label="Status" name="flightStatus" value={flightForm.flightStatus} onChange={setField(setFlightForm)} options={['SCHEDULED', 'DELAYED', 'CANCELLED']} />
          <button className="primary-btn" type="submit">Save flight</button>
        </form>
        <MiniList items={data.flights} title={(item) => `${item.flightNumber} ${item.source}-${item.destination}`} detail={(item) => `${item.airline} - ${formatMoney(item.price)}`} onEdit={setFlightForm} onDelete={(item) => remove('flights', item.id)} />
      </Panel>

      <Panel title="Users">
        <form onSubmit={saveUser}>
          {['firstName', 'lastName', 'email', 'phoneNumber', 'password', 'dateOfBirth', 'gender', 'nationality', 'passportNumber', 'address'].map((field) => (
            <Field key={field} label={labelize(field)} name={field} type={field === 'dateOfBirth' ? 'date' : field === 'password' ? 'password' : 'text'} value={userForm[field] || ''} onChange={setField(setUserForm)} />
          ))}
          <button className="primary-btn" type="submit">Save user</button>
        </form>
        <MiniList items={data.users} title={(item) => `${item.firstName} ${item.lastName}`} detail={(item) => item.email} onEdit={(item) => setUserForm({ ...item, password: '' })} onDelete={(item) => remove('users', item.id)} />
      </Panel>

      <Panel title="Seats">
        <form onSubmit={saveSeat}>
          <Field label="Flight ID" name="flightId" type="number" value={seatForm.flightId} onChange={setField(setSeatForm)} />
          <Field label="Seat number" name="seatNumber" value={seatForm.seatNumber} onChange={setField(setSeatForm)} />
          <Select label="Type" name="seatType" value={seatForm.seatType} onChange={setField(setSeatForm)} options={['Window', 'Aisle', 'Middle']} />
          <Select label="Class" name="seatClass" value={seatForm.seatClass} onChange={setField(setSeatForm)} options={['Economy', 'Business', 'First']} />
          <Field label="Price" name="price" type="number" value={seatForm.price} onChange={setField(setSeatForm)} />
          <Select label="Status" name="status" value={seatForm.status} onChange={setField(setSeatForm)} options={['AVAILABLE', 'RESERVED']} />
          <button className="primary-btn" type="submit">Save seat</button>
        </form>
        <MiniList items={data.seats} title={(item) => `${item.seatNumber} - Flight ${item.flightId}`} detail={(item) => `${item.seatClass} - ${item.status}`} onEdit={setSeatForm} onToggle={reserveOrRelease} toggleLabel={(item) => (item.status === 'AVAILABLE' ? 'Reserve' : 'Release')} onDelete={(item) => remove('seats', item.id)} />
      </Panel>

      <Panel title="Bookings">
        <form onSubmit={updateBooking}>
          {['id', 'userId', 'flightId', 'seatId', 'totalFare'].map((field) => (
            <Field key={field} label={labelize(field)} name={field} type="number" value={bookingEdit[field]} onChange={setField(setBookingEdit)} />
          ))}
          <Select label="Booking status" name="bookingStatus" value={bookingEdit.bookingStatus} onChange={setField(setBookingEdit)} options={['CONFIRMED', 'PENDING', 'CANCELLED']} />
          <Select label="Payment status" name="paymentStatus" value={bookingEdit.paymentStatus} onChange={setField(setBookingEdit)} options={['PAID', 'PENDING', 'FAILED']} />
          <button className="primary-btn" type="submit">Update booking</button>
        </form>
        <MiniList items={data.bookings} title={(item) => item.bookingReference} detail={(item) => `Seat ${item.seatNumber} - ${item.bookingStatus}`} onEdit={setBookingEdit} onDelete={(item) => remove('bookings', item.id)} />
      </Panel>

      <Panel title="Tickets">
        <form onSubmit={updateTicket}>
          <Field label="Ticket ID" name="id" type="number" value={ticketEdit.id} onChange={setField(setTicketEdit)} />
          <Field label="Booking ID" name="bookingId" type="number" value={ticketEdit.bookingId} onChange={setField(setTicketEdit)} />
          <Select label="Status" name="ticketStatus" value={ticketEdit.ticketStatus} onChange={setField(setTicketEdit)} options={['ISSUED', 'CANCELLED']} />
          <button className="primary-btn" type="submit">Update ticket</button>
        </form>
        <MiniList items={data.tickets} title={(item) => item.ticketNumber} detail={(item) => `Booking ${item.bookingId} - ${item.ticketStatus}`} onEdit={setTicketEdit} onToggle={(item) => cancelTicket(item.id)} toggleLabel={() => 'Cancel'} onDelete={(item) => remove('tickets', item.id)} />
      </Panel>
    </div>
  )
}

function ApiToolResults({ apiTools }) {
  const hasResults =
    apiTools.lookupResult ||
    apiTools.flightSearchResult ||
    apiTools.ticketLookupResult ||
    apiTools.directTicketResult

  if (!hasResults) {
    return <p className="compact">Run an API tool to see formatted results here.</p>
  }

  return (
    <div className="api-results">
      {apiTools.lookupResult && (
        <ResultSection title="Lookup result">
          <KeyValueCard data={apiTools.lookupResult} />
        </ResultSection>
      )}

      {apiTools.flightSearchResult && (
        <ResultSection title="Flight-service search results">
          <div className="api-flight-list">
            {apiTools.flightSearchResult.length ? (
              apiTools.flightSearchResult.map((flight) => (
                <article className="api-flight-card" key={flight.id}>
                  <div>
                    <strong>{flight.airline}</strong>
                    <span>{flight.flightNumber}</span>
                  </div>
                  <div>
                    <b>{flight.source}</b>
                    <span>{flight.departureTime?.slice(0, 5)} to {flight.arrivalTime?.slice(0, 5)}</span>
                    <b>{flight.destination}</b>
                  </div>
                  <div>
                    <span>{flight.departureDate}</span>
                    <span>{flight.duration}</span>
                    <strong>{formatMoney(flight.price)}</strong>
                  </div>
                </article>
              ))
            ) : (
              <p className="compact">No flights matched this route.</p>
            )}
          </div>
        </ResultSection>
      )}

      {apiTools.ticketLookupResult && (
        <ResultSection title="Ticket by booking">
          <TicketSummary ticket={apiTools.ticketLookupResult} />
        </ResultSection>
      )}

      {apiTools.directTicketResult && (
        <ResultSection title="Generated ticket">
          <TicketSummary ticket={apiTools.directTicketResult} />
        </ResultSection>
      )}
      {apiTools.bookingsByUserResult && (
        <ResultSection title="Bookings by user"><div className="api-flight-list">{apiTools.bookingsByUserResult.map((booking) => <KeyValueCard key={booking.id} data={booking} />)}</div></ResultSection>
      )}
    </div>
  )
}

function ResultSection({ title, children }) {
  return (
    <section className="result-section">
      <h3>{title}</h3>
      {children}
    </section>
  )
}

function KeyValueCard({ data }) {
  return (
    <dl className="key-value-card">
      {Object.entries(data).map(([key, value]) => (
        <div key={key}>
          <dt>{labelize(key)}</dt>
          <dd>{String(value ?? '-')}</dd>
        </div>
      ))}
    </dl>
  )
}

function TicketSummary({ ticket }) {
  return (
    <article className="ticket-summary">
      <strong>{ticket.ticketNumber || `Ticket ${ticket.id}`}</strong>
      <span>Booking {ticket.bookingId}</span>
      <span>Flight {ticket.flightId}</span>
      <span>User {ticket.userId}</span>
      <span>Seat {ticket.seatNumber}</span>
      <b>{ticket.ticketStatus}</b>
    </article>
  )
}
