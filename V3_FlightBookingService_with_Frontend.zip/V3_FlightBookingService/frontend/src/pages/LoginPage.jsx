import { useState } from 'react'
import { useDispatch } from 'react-redux'
import { Link, useLocation, useNavigate } from 'react-router-dom'
import { authApi } from '../api'
import { setSession } from '../redux/authSlice'
import { Field } from '../components/FormControls'

export function AuthShell({ title, subtitle, children }) { return <main className="auth-shell"><div className="auth-card"><p className="eyebrow">AeroSwift</p><h1>{title}</h1><p>{subtitle}</p>{children}</div></main> }
export function LoginPage() {
  const dispatch = useDispatch(); const navigate = useNavigate(); const location = useLocation(); const [form, setForm] = useState({ email: '', password: '' }); const [error, setError] = useState(''); const [loading, setLoading] = useState(false)
  const submit = async (event) => { event.preventDefault(); setLoading(true); setError(''); try { const session = await authApi.login(form); dispatch(setSession({ token: session.token, user: session })); navigate(new URLSearchParams(location.search).get('from') || '/', { replace: true }) } catch (e) { setError(e.message) } finally { setLoading(false) } }
  return <AuthShell title="Welcome back" subtitle="Sign in to continue your booking."><form className="auth-form" onSubmit={submit}><Field label="Email" name="email" type="email" value={form.email} onChange={(e) => setForm({ ...form, email: e.target.value })} /><Field label="Password" name="password" type="password" value={form.password} onChange={(e) => setForm({ ...form, password: e.target.value })} /><button className="primary-btn" disabled={loading}>{loading ? 'Signing in…' : 'Sign in'}</button>{error && <p className="notice error">{error}</p>}</form><p className="auth-link">New to AeroSwift? <Link to="/register">Create an account</Link></p></AuthShell>
}
