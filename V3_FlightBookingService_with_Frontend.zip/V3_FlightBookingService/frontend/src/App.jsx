import { useCallback, useEffect, useMemo, useState } from 'react'
import { useDispatch, useSelector } from 'react-redux'
import { logout } from './redux/authSlice'
import { setData } from './redux/dataSlice'
import { bookingApi, flightApi, seatApi, ticketApi, userApi } from './api'
import './App.css'
import { Layout } from './components/Layout'
import { ToastStack } from './components/ToastStack'
import { AppRoutes } from './routes/AppRoutes'

function App() {
  const [notice, setNotice] = useState('')
  const [loading, setLoading] = useState(false)
  const [toasts, setToasts] = useState([])
  const dispatch = useDispatch()
  const data = useSelector((state) => state.data)
  const auth = useSelector((state) => state.auth)
  const isAdmin = auth.user?.role === 'ROLE_ADMIN' || auth.user?.role === 'ADMIN'

  const stats = useMemo(
    () => [
      ['Flights', data.flights.length],
      ['Seats', data.seats.length],
      ['Bookings', data.bookings.length],
      ['Tickets', data.tickets.length],
    ],
    [data],
  )

  const showToast = useCallback((message, type = 'success') => {
    const id = crypto.randomUUID?.() || `${Date.now()}-${Math.random()}`
    setToasts((current) => [...current, { id, message, type }])
    window.setTimeout(() => {
      setToasts((current) => current.filter((toast) => toast.id !== id))
    }, 4200)
  }, [])

  const refreshData = useCallback(async () => {
    setLoading(true)
    try {
      const results = await Promise.allSettled([
        flightApi.list(),
        isAdmin ? userApi.list() : Promise.resolve(auth.user ? [auth.user] : []),
        isAdmin ? seatApi.list() : Promise.resolve([]),
        isAdmin ? bookingApi.list() : Promise.resolve([]),
        isAdmin ? ticketApi.list() : Promise.resolve([]),
      ])
      const names = ['flights', 'users', 'seats', 'bookings', 'tickets']
      const payload = {}
      const errors = []
      results.forEach((result, index) => {
        if (result.status === 'fulfilled') payload[names[index]] = result.value
        else errors.push(`${names[index]}: ${result.reason.message}`)
      })
      dispatch(setData(payload))
      if (errors.length) {
        const message = `Some service data could not be refreshed. ${errors.join(' | ')}`
        setNotice(message)
        showToast(message, 'error')
      } else setNotice('Live service data loaded.')
    } finally {
      setLoading(false)
    }
  }, [auth.user, dispatch, isAdmin, showToast])

  const dismissToast = (id) => {
    setToasts((current) => current.filter((toast) => toast.id !== id))
  }

  useEffect(() => {
    // Initial service hydration for every route.
    // eslint-disable-next-line react-hooks/set-state-in-effect
    if (auth.token || window.location.pathname === '/') refreshData()
  }, [auth.token, refreshData])

  return (
    <Layout loading={loading} notice={notice} onRefresh={refreshData} stats={stats} user={auth.user} onLogout={() => dispatch(logout())}>
      <AppRoutes
        data={data}
        refreshData={refreshData}
        setLoading={setLoading}
        setNotice={setNotice}
        showToast={showToast}
        users={data.users}
      />
      <ToastStack toasts={toasts} onDismiss={dismissToast} />
    </Layout>
  )
}

export default App
