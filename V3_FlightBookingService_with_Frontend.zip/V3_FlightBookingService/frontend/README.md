# AeroSwift Frontend

AeroSwift is the front-end user interface for the Flight Booking System. It supports the full end-to-end workflow:

- Search flights
- Select a seat
- Create a booking
- Generate a ticket

This frontend uses the backend microservices defined in the repository and integrates with them using REST APIs through the configured service URLs.

## What AeroSwift Does

The frontend provides two main experiences:

1. **Booking Experience**
   - Search for flights by source, destination, departure date, passenger count, and travel class
   - View matching flights returned by `search-service`
   - Select a flight and choose an available seat from `seat-service`
   - Confirm a booking through `booking-service`
   - Generate a ticket through `ticket-service`

2. **Management Tools**
   - Create, update, and delete flights, users, seats, bookings, and tickets
   - Look up records by ID across services
   - Reserve or release seats directly
   - Run direct backend calls for `flight-service` searches and ticket lookups

## Project Structure

- `src/App.jsx` — application shell, data hydration, global state, and notifications
- `src/routes/AppRoutes.jsx` — routes for booking and management views
- `src/pages/BookingPage.jsx` — booking workflow UI and ticket generation
- `src/pages/ManagementPage.jsx` — service admin and API tooling UI
- `src/api/index.js` — REST API client for flights, users, seats, bookings, tickets, and search
- `src/api/client.js` — request helper and service base URL configuration

## Supported Backend Endpoints

AeroSwift calls the following service endpoints:

- `search-service` at `/search` for flight search
- `flight-service` at `/flights` for direct flight lookup and management
- `seat-service` at `/seats` for seat listings, reservation, and release
- `booking-service` at `/bookings` for booking creation and management
- `ticket-service` at `/tickets` for ticket generation and management

The frontend expects the backend ports shown in the repository documentation:

- `flight-service` → `http://localhost:8081`
- `user-service` → `http://localhost:8082`
- `search-service` → `http://localhost:8083`
- `booking-service` → `http://localhost:8084`
- `seat-service` → `http://localhost:8085`
- `ticket-service` → `http://localhost:8086`

These are configurable via environment variables if needed.

## Running AeroSwift

From the `frontend` folder, install dependencies and run the Vite development server:

```bash
npm install
npm run dev
```

Open the URL shown by Vite in your browser.

## Booking Workflow

1. Open the main AeroSwift page.
2. Enter flight search criteria and submit the search form.
3. Select a matching flight from the results.
4. Choose an available seat for that flight.
5. Select a passenger and payment status.
6. Confirm the booking.
7. After booking succeeds, generate a ticket with the issued booking.

The frontend shows the latest booking reference, seat number, and ticket number after each successful action.

## Management Page

The `/manage` view includes tools for:

- Adding and editing flights, users, seats, bookings, and tickets
- Reserving or releasing seats
- Looking up records by service and ID
- Running search queries directly against `flight-service`
- Generating tickets through direct `POST /tickets`

Use this page to seed test data or verify integrations during development.

## Environment Configuration

The frontend uses `src/api/client.js` to build service URLs from environment variables.

Supported variables:

- `VITE_FLIGHT_API_URL`
- `VITE_USER_API_URL`
- `VITE_SEARCH_API_URL`
- `VITE_BOOKING_API_URL`
- `VITE_SEAT_API_URL`
- `VITE_TICKET_API_URL`

If not provided, the frontend falls back to the default local ports.

## Notes

- The booking flow depends on valid existing users, flights, and available seats in the backend services.
- The frontend is intentionally lightweight and mirrors the service-oriented architecture described in `API_REFERENCE.md` and `ARCHITECTURE.md`.
- The ticket generation step uses `ticket-service` to verify booking ownership and resolve seat details from `booking-service`.

## Helpful Links

- `../API_REFERENCE.md` — backend API contract and service endpoint details
- `../ARCHITECTURE.md` — microservice architecture and integration overview
- `../INTEGRATION_PROGRESS.md` — current integration status and verification steps
