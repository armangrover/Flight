# Frontend Refactoring Task

The backend is complete. Do NOT modify backend APIs, endpoints, request/response models, or business logic.

Refactor the existing React frontend into a modular production-ready application without changing functionality.

ONLY WORK UNDER ./frontend folder

## Requirements

- Use React Router DOM for navigation.
- Use Redux Toolkit for global state.
- Use Axios with a single shared instance and JWT interceptor.
- Split the current single-page application into reusable pages and components.
- Keep business logic separate from UI.
- Reuse existing code wherever possible.
- Do NOT redesign the UI unless necessary.
- Do NOT add unnecessary dependencies.

## Suggested Structure

```
src/
│
├── app/
│   └── store.js
│
├── routes/
│   ├── AppRoutes.jsx
│   ├── ProtectedRoute.jsx
│   └── AdminRoute.jsx
│
├── layouts/
│   ├── MainLayout.jsx
│   ├── DashboardLayout.jsx
│   └── AdminLayout.jsx
│
├── pages/
│   ├── Home/
│   ├── Login/
│   ├── Register/
│   ├── SearchFlights/
│   ├── FlightDetails/
│   ├── SeatSelection/
│   ├── Booking/
│   ├── Ticket/
│   ├── BookingHistory/
│   ├── Profile/
│   ├── Admin/
│   │     ├── Dashboard/
│   │     ├── Flights/
│   │     ├── Seats/
│   │     ├── Users/
│   │     └── Bookings/
│   └── NotFound/
│
├── components/
│   ├── Navbar/
│   ├── Footer/
│   ├── FlightCard/
│   ├── FlightTable/
│   ├── SearchForm/
│   ├── SeatGrid/
│   ├── BookingCard/
│   ├── TicketCard/
│   ├── ProfileForm/
│   ├── Sidebar/
│   ├── Header/
│   ├── Pagination/
│   ├── Loader/
│   ├── Error/
│   ├── EmptyState/
│   ├── ConfirmDialog/
│   └── Protected/
│
├── redux/
│   ├── auth/
│   ├── user/
│   ├── flights/
│   ├── seats/
│   ├── bookings/
│   ├── tickets/
│   └── search/
│
├── services/
│   ├── api.js
│   ├── authService.js
│   ├── flightService.js
│   ├── bookingService.js
│   ├── seatService.js
│   ├── searchService.js
│   ├── ticketService.js
│   └── userService.js
│
├── hooks/
│
├── utils/
│
├── constants/
│
├── assets/
│
└── styles/
```


## Routing

Implement:

- Protected Routes
- Admin Routes
- Nested Routes
- 404 Route

## API Layer

Create service files for:

- auth
- user
- flights
- search
- seats
- bookings
- tickets

Use one Axios instance with request/response interceptors.

## Authentication

- Store JWT.
- Restore session on refresh.
- Redirect unauthenticated users to login.
- Restrict admin pages by role.

## Refactoring Rules

- Reuse existing components whenever possible.
- Create small reusable components.
- Avoid duplicate code.
- Keep files focused on a single responsibility.
- Keep Redux logic inside slices.
- Keep API calls inside services.
- Do not change backend contracts.

Work incrementally. Refactor one feature/page at a time, verify it works, then continue. Avoid unnecessary rewrites or file creation.