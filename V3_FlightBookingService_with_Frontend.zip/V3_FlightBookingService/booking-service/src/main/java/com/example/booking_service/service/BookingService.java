package com.example.booking_service.service;

import java.util.List;

import com.example.booking_service.dto.BookingRequestDto;
import com.example.booking_service.dto.BookingResponseDto;

public interface BookingService {

    BookingResponseDto createBooking(BookingRequestDto bookingRequestDto);

    List<BookingResponseDto> getAllBookings();

    BookingResponseDto getBookingById(Long id);

    List<BookingResponseDto> getBookingsByUserId(Long userId);

    BookingResponseDto updateBooking(Long id, BookingRequestDto bookingRequestDto);

    BookingResponseDto cancelBooking(Long id);

    void deleteBooking(Long id);
}
