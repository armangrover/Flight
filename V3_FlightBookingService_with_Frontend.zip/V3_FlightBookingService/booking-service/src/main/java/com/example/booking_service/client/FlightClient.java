package com.example.booking_service.client;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PutMapping;

import com.example.booking_service.dto.FlightResponseDto;

@FeignClient(name = "flight-service-client", url = "${flight.service.url}")
public interface FlightClient {

    @GetMapping("/flights/{id}")
    FlightResponseDto getFlightById(@PathVariable("id") Long id);

    @PutMapping("/flights/{id}/decrease-available-seats")
    FlightResponseDto decreaseAvailableSeats(@PathVariable("id") Long id);

    @PutMapping("/flights/{id}/increase-available-seats")
    FlightResponseDto increaseAvailableSeats(@PathVariable("id") Long id);
}
