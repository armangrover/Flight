package com.example.booking_service.client;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PutMapping;

import com.example.booking_service.dto.TicketResponseDto;

@FeignClient(name = "ticket-service-client", url = "${ticket.service.url}")
public interface TicketClient {

    @PutMapping("/tickets/booking/{bookingId}/cancel")
    TicketResponseDto cancelTicketByBookingId(@PathVariable("bookingId") Long bookingId);
}
