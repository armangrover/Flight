package com.example.booking_service.dto;

import java.math.BigDecimal;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class SeatResponseDto {

    private Long id;
    private Long flightId;
    private String seatNumber;
    private String seatType;
    private String seatClass;
    private BigDecimal price;
    private String status;
}
