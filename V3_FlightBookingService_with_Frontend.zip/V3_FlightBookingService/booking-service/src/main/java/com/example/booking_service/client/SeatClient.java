package com.example.booking_service.client;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PutMapping;

import com.example.booking_service.dto.SeatResponseDto;

@FeignClient(name = "seat-service-client", url = "${seat.service.url}")
public interface SeatClient {

    @GetMapping("/seats/{id}")
    SeatResponseDto getSeatById(@PathVariable("id") Long id);

    @PutMapping("/seats/{id}/reserve")
    SeatResponseDto reserveSeat(@PathVariable("id") Long id);

    @PutMapping("/seats/{id}/release")
    SeatResponseDto releaseSeat(@PathVariable("id") Long id);
}
