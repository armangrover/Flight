package com.example.booking_service.dto;

import java.math.BigDecimal;

import jakarta.validation.constraints.DecimalMin;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Positive;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class BookingRequestDto {

    @NotNull(message = "User id is required")
    @Positive(message = "User id must be greater than zero")
    private Long userId;

    @NotNull(message = "Flight id is required")
    @Positive(message = "Flight id must be greater than zero")
    private Long flightId;

    @NotNull(message = "Seat id is required")
    @Positive(message = "Seat id must be greater than zero")
    private Long seatId;

    @NotBlank(message = "Booking status is required")
    private String bookingStatus;

    @NotBlank(message = "Payment status is required")
    private String paymentStatus;

    @NotNull(message = "Total fare is required")
    @DecimalMin(value = "0.0", inclusive = false, message = "Total fare must be greater than zero")
    private BigDecimal totalFare;
}
