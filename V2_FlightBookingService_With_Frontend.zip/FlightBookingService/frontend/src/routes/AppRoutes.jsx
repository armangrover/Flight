import { BookingPage } from '../pages/BookingPage'
import { ManagementPage } from '../pages/ManagementPage'

export function AppRoutes(props) {
  if (window.location.pathname === '/manage') {
    return <ManagementPage {...props} />
  }

  return <BookingPage {...props} />
}
