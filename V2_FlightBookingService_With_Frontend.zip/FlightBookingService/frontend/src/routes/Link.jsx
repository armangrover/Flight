export function Link({ href, label }) {
  const active = window.location.pathname === href

  return (
    <a className={active ? 'active' : ''} href={href}>
      {label}
    </a>
  )
}
