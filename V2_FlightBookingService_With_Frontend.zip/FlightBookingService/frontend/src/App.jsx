import { useCallback, useEffect, useMemo, useState } from 'react'
import { bookingApi, flightApi, seatApi, ticketApi, userApi } from './api'
import './App.css'
import { Layout } from './components/Layout'
import { ToastStack } from './components/ToastStack'
import { AppRoutes } from './routes/AppRoutes'

function App() {
  const [notice, setNotice] = useState('')
  const [loading, setLoading] = useState(false)
  const [toasts, setToasts] = useState([])
  const [data, setData] = useState({
    flights: [],
    users: [],
    seats: [],
    bookings: [],
    tickets: [],
  })

  const stats = useMemo(
    () => [
      ['Flights', data.flights.length],
      ['Seats', data.seats.length],
      ['Bookings', data.bookings.length],
      ['Tickets', data.tickets.length],
    ],
    [data],
  )

  const showToast = useCallback((message, type = 'success') => {
    const id = crypto.randomUUID?.() || `${Date.now()}-${Math.random()}`
    setToasts((current) => [...current, { id, message, type }])
    window.setTimeout(() => {
      setToasts((current) => current.filter((toast) => toast.id !== id))
    }, 4200)
  }, [])

  const refreshData = useCallback(async () => {
    setLoading(true)
    try {
      const [flights, users, seats, bookings, tickets] = await Promise.all([
        flightApi.list(),
        userApi.list(),
        seatApi.list(),
        bookingApi.list(),
        ticketApi.list(),
      ])
      setData({ flights, users, seats, bookings, tickets })
      setNotice('Live service data loaded.')
    } catch (error) {
      setNotice(error.message)
      showToast(error.message, 'error')
    } finally {
      setLoading(false)
    }
  }, [showToast])

  const dismissToast = (id) => {
    setToasts((current) => current.filter((toast) => toast.id !== id))
  }

  useEffect(() => {
    // Initial service hydration for every route.
    // eslint-disable-next-line react-hooks/set-state-in-effect
    refreshData()
  }, [refreshData])

  return (
    <Layout loading={loading} notice={notice} onRefresh={refreshData} stats={stats}>
      <AppRoutes
        data={data}
        refreshData={refreshData}
        setLoading={setLoading}
        setNotice={setNotice}
        showToast={showToast}
        users={data.users}
      />
      <ToastStack toasts={toasts} onDismiss={dismissToast} />
    </Layout>
  )
}

export default App
