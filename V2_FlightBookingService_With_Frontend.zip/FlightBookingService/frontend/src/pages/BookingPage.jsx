import { useState } from 'react'
import { bookingApi, searchApi, seatApi, ticketApi } from '../api'
import { Field, Select } from '../components/FormControls'
import { FlightCard } from '../components/FlightCard'
import { today } from '../utils/date'
import { formatMoney } from '../utils/format'

export function BookingPage({ users, refreshData, setLoading, setNotice, showToast }) {
  const [searchForm, setSearchForm] = useState({
    source: 'Delhi',
    destination: 'Mumbai',
    departureDate: today,
    returnDate: '',
    numberOfPassengers: 1,
    travelClass: 'Economy',
  })
  const [results, setResults] = useState([])
  const [selectedFlight, setSelectedFlight] = useState(null)
  const [flightSeats, setFlightSeats] = useState([])
  const [selectedSeat, setSelectedSeat] = useState(null)
  const [bookingForm, setBookingForm] = useState({ userId: '', paymentStatus: 'PAID' })
  const [latestBooking, setLatestBooking] = useState(null)
  const [latestTicket, setLatestTicket] = useState(null)

  const setField = (setter) => (event) => {
    const { name, value } = event.target
    setter((current) => ({ ...current, [name]: value }))
  }

  const success = (message) => {
    setNotice(message)
    showToast(message, 'success')
  }

  const fail = (error) => {
    setNotice(error.message)
    showToast(error.message, 'error')
  }

  const handleSearch = async (event) => {
    event.preventDefault()
    setLoading(true)
    setSelectedFlight(null)
    setSelectedSeat(null)
    setLatestBooking(null)
    setLatestTicket(null)
    try {
      const matches = await searchApi.searchFlights({
        ...searchForm,
        returnDate: searchForm.returnDate || '',
      })
      setResults(matches)
      success(matches.length ? 'Flights matched your route.' : 'No flights found.')
    } catch (error) {
      fail(error)
    } finally {
      setLoading(false)
    }
  }

  const chooseFlight = async (flight) => {
    setSelectedFlight(flight)
    setSelectedSeat(null)
    setLatestBooking(null)
    setLatestTicket(null)
    setLoading(true)
    try {
      setFlightSeats(await seatApi.byFlight(flight.id))
      success(`Choose a seat for ${flight.flightNumber}.`)
    } catch (error) {
      setFlightSeats([])
      fail(error)
    } finally {
      setLoading(false)
    }
  }

  const createBooking = async (event) => {
    event.preventDefault()
    if (!selectedFlight || !selectedSeat) {
      success('Select a flight and an available seat first.')
      return
    }
    setLoading(true)
    try {
      const booking = await bookingApi.create({
        userId: Number(bookingForm.userId),
        flightId: selectedFlight.id,
        seatId: selectedSeat.id,
        bookingStatus: 'CONFIRMED',
        paymentStatus: bookingForm.paymentStatus,
        totalFare: Number(selectedSeat.price || selectedFlight.price),
      })
      setLatestBooking(booking)
      success(`Booking confirmed: ${booking.bookingReference}`)
      await refreshData()
    } catch (error) {
      fail(error)
    } finally {
      setLoading(false)
    }
  }

  const generateTicket = async () => {
    if (!latestBooking) return
    setLoading(true)
    try {
      const ticket = await ticketApi.generate({
        bookingId: latestBooking.id,
        ticketStatus: 'ISSUED',
      })
      setLatestTicket(ticket)
      success(`Ticket issued: ${ticket.ticketNumber}`)
      await refreshData()
    } catch (error) {
      fail(error)
    } finally {
      setLoading(false)
    }
  }

  const availableSeats = flightSeats.filter((seat) => seat.status === 'AVAILABLE')

  return (
    <div className="traveler-grid">
      <form className="booking-search" onSubmit={handleSearch}>
        <Field label="From" name="source" value={searchForm.source} onChange={setField(setSearchForm)} />
        <Field label="To" name="destination" value={searchForm.destination} onChange={setField(setSearchForm)} />
        <Field label="Depart" name="departureDate" type="date" value={searchForm.departureDate} onChange={setField(setSearchForm)} />
        <Field label="Return" name="returnDate" type="date" value={searchForm.returnDate} onChange={setField(setSearchForm)} />
        <Field label="Passengers" name="numberOfPassengers" type="number" min="1" value={searchForm.numberOfPassengers} onChange={setField(setSearchForm)} />
        <Select label="Class" name="travelClass" value={searchForm.travelClass} onChange={setField(setSearchForm)} options={['Economy', 'Business', 'First']} />
        <button className="primary-btn" type="submit">Search flights</button>
      </form>

      <div className="results-list">
        {results.map((flight) => (
          <FlightCard
            flight={flight}
            key={flight.id}
            onSelect={chooseFlight}
            selected={selectedFlight?.id === flight.id}
          />
        ))}
      </div>

      <aside className="checkout-panel">
        <h2>Seat and checkout</h2>
        {selectedFlight ? (
          <>
            <p className="compact">
              {selectedFlight.flightNumber} from {selectedFlight.source} to {selectedFlight.destination}
            </p>
            <div className="seat-map">
              {availableSeats.map((seat) => (
                <button
                  className={selectedSeat?.id === seat.id ? 'seat selected' : 'seat'}
                  key={seat.id}
                  type="button"
                  onClick={() => setSelectedSeat(seat)}
                >
                  {seat.seatNumber}
                  <small>{formatMoney(seat.price)}</small>
                </button>
              ))}
            </div>
            <form onSubmit={createBooking}>
              <Select
                label="Passenger"
                name="userId"
                value={bookingForm.userId}
                onChange={setField(setBookingForm)}
                options={users.map((user) => ({
                  label: `${user.firstName} ${user.lastName}`,
                  value: user.id,
                }))}
              />
              <Select
                label="Payment"
                name="paymentStatus"
                value={bookingForm.paymentStatus}
                onChange={setField(setBookingForm)}
                options={['PAID', 'PENDING', 'FAILED']}
              />
              <button className="primary-btn" type="submit">Confirm booking</button>
            </form>
          </>
        ) : (
          <p className="compact">Select a flight to see available seats.</p>
        )}

        {latestBooking && (
          <div className="ticket-box">
            <strong>{latestBooking.bookingReference}</strong>
            <span>Seat {latestBooking.seatNumber}</span>
            <button type="button" onClick={generateTicket}>Generate ticket</button>
          </div>
        )}
        {latestTicket && (
          <div className="ticket-box issued">
            <strong>{latestTicket.ticketNumber}</strong>
            <span>{latestTicket.ticketStatus}</span>
          </div>
        )}
      </aside>
    </div>
  )
}
