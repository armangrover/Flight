export const API_BASE_URLS = {
  flights: import.meta.env.VITE_FLIGHT_API_URL || 'http://localhost:8081',
  users: import.meta.env.VITE_USER_API_URL || 'http://localhost:8082',
  search: import.meta.env.VITE_SEARCH_API_URL || 'http://localhost:8083',
  bookings: import.meta.env.VITE_BOOKING_API_URL || 'http://localhost:8084',
  seats: import.meta.env.VITE_SEAT_API_URL || 'http://localhost:8085',
  tickets: import.meta.env.VITE_TICKET_API_URL || 'http://localhost:8086',
}

export async function request(service, path, options = {}) {
  const response = await fetch(`${API_BASE_URLS[service]}${path}`, {
    headers: options.body ? { 'Content-Type': 'application/json' } : undefined,
    ...options,
  })

  if (!response.ok) {
    let message = `Request failed with status ${response.status}`
    try {
      const error = await response.json()
      message = formatBackendError(error, message)
    } catch {
      message = response.statusText || message
    }
    throw new Error(message)
  }

  if (response.status === 204) return null
  const text = await response.text()
  return text ? JSON.parse(text) : null
}

export function queryString(params) {
  return new URLSearchParams(params).toString()
}

function formatBackendError(error, fallback) {
  if (!error || typeof error !== 'object') return fallback

  const fieldErrors = error.errors
    ? Object.entries(error.errors).map(([field, value]) => `${field}: ${value}`)
    : []

  return [error.message || error.error || fallback, ...fieldErrors].join(' | ')
}
