import { queryString, request } from './client'

export const searchApi = {
  searchFlights: (params) => request('search', `/search?${queryString(params)}`),
}

export const flightApi = {
  list: () => request('flights', '/flights'),
  get: (id) => request('flights', `/flights/${id}`),
  search: (params) => request('flights', `/flights/search?${queryString(params)}`),
  create: (body) => request('flights', '/flights', post(body)),
  update: (id, body) => request('flights', `/flights/${id}`, put(body)),
  remove: (id) => request('flights', `/flights/${id}`, { method: 'DELETE' }),
}

export const userApi = {
  list: () => request('users', '/users'),
  get: (id) => request('users', `/users/${id}`),
  create: (body) => request('users', '/users', post(body)),
  update: (id, body) => request('users', `/users/${id}`, put(body)),
  remove: (id) => request('users', `/users/${id}`, { method: 'DELETE' }),
}

export const seatApi = {
  list: () => request('seats', '/seats'),
  get: (id) => request('seats', `/seats/${id}`),
  byFlight: (flightId) => request('seats', `/seats/flight/${flightId}`),
  create: (body) => request('seats', '/seats', post(body)),
  update: (id, body) => request('seats', `/seats/${id}`, put(body)),
  reserve: (id) => request('seats', `/seats/${id}/reserve`, { method: 'PUT' }),
  release: (id) => request('seats', `/seats/${id}/release`, { method: 'PUT' }),
  remove: (id) => request('seats', `/seats/${id}`, { method: 'DELETE' }),
}

export const bookingApi = {
  list: () => request('bookings', '/bookings'),
  get: (id) => request('bookings', `/bookings/${id}`),
  create: (body) => request('bookings', '/bookings', post(body)),
  update: (id, body) => request('bookings', `/bookings/${id}`, put(body)),
  remove: (id) => request('bookings', `/bookings/${id}`, { method: 'DELETE' }),
}

export const ticketApi = {
  list: () => request('tickets', '/tickets'),
  get: (id) => request('tickets', `/tickets/${id}`),
  byBooking: (bookingId) => request('tickets', `/tickets/booking/${bookingId}`),
  create: (body) => request('tickets', '/tickets', post(body)),
  generate: (body) => request('tickets', '/tickets/generate', post(body)),
  update: (id, body) => request('tickets', `/tickets/${id}`, put(body)),
  cancel: (id) => request('tickets', `/tickets/${id}/cancel`, { method: 'PUT' }),
  remove: (id) => request('tickets', `/tickets/${id}`, { method: 'DELETE' }),
}

export const apiByResource = {
  flights: flightApi,
  users: userApi,
  seats: seatApi,
  bookings: bookingApi,
  tickets: ticketApi,
}

function post(body) {
  return { method: 'POST', body: JSON.stringify(body) }
}

function put(body) {
  return { method: 'PUT', body: JSON.stringify(body) }
}
