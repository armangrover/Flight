package com.example.seat_service.service.impl;

import java.util.List;

import org.springframework.stereotype.Service;

import com.example.seat_service.dto.SeatRequestDto;
import com.example.seat_service.dto.SeatResponseDto;
import com.example.seat_service.entity.Seat;
import com.example.seat_service.exception.SeatNotFoundException;
import com.example.seat_service.repository.SeatRepository;
import com.example.seat_service.service.SeatService;

@Service
public class SeatServiceImpl implements SeatService {

    private static final String AVAILABLE = "AVAILABLE";
    private static final String RESERVED = "RESERVED";

    private final SeatRepository seatRepository;

    public SeatServiceImpl(SeatRepository seatRepository) {
        this.seatRepository = seatRepository;
    }

    @Override
    public SeatResponseDto createSeat(SeatRequestDto seatRequestDto) {
        validateSeatRequest(seatRequestDto);
        Seat seat = mapToEntity(seatRequestDto);
        Seat savedSeat = seatRepository.save(seat);
        return mapToResponseDto(savedSeat);
    }

    @Override
    public List<SeatResponseDto> getAllSeats() {
        return seatRepository.findAll()
                .stream()
                .map(this::mapToResponseDto)
                .toList();
    }

    @Override
    public SeatResponseDto getSeatById(Long id) {
        return mapToResponseDto(findSeatById(id));
    }

    @Override
    public SeatResponseDto updateSeat(Long id, SeatRequestDto seatRequestDto) {
        validateSeatRequest(seatRequestDto);
        Seat existingSeat = findSeatById(id);

        existingSeat.setFlightId(seatRequestDto.getFlightId());
        existingSeat.setSeatNumber(seatRequestDto.getSeatNumber());
        existingSeat.setSeatType(seatRequestDto.getSeatType());
        existingSeat.setSeatClass(seatRequestDto.getSeatClass());
        existingSeat.setPrice(seatRequestDto.getPrice());
        existingSeat.setStatus(normalizeStatus(seatRequestDto.getStatus()));

        Seat updatedSeat = seatRepository.save(existingSeat);
        return mapToResponseDto(updatedSeat);
    }

    @Override
    public void deleteSeat(Long id) {
        Seat seat = findSeatById(id);
        seatRepository.delete(seat);
    }

    @Override
    public List<SeatResponseDto> getSeatsByFlightId(Long flightId) {
        return seatRepository.findByFlightId(flightId)
                .stream()
                .map(this::mapToResponseDto)
                .toList();
    }

    @Override
    public SeatResponseDto reserveSeat(Long id) {
        Seat seat = findSeatById(id);
        String normalizedStatus = normalizeStatus(seat.getStatus());

        if (RESERVED.equals(normalizedStatus)) {
            throw new IllegalArgumentException("Seat is already reserved");
        }

        seat.setStatus(RESERVED);
        Seat updatedSeat = seatRepository.save(seat);
        return mapToResponseDto(updatedSeat);
    }

    @Override
    public SeatResponseDto releaseSeat(Long id) {
        Seat seat = findSeatById(id);
        String normalizedStatus = normalizeStatus(seat.getStatus());

        if (AVAILABLE.equals(normalizedStatus)) {
            throw new IllegalArgumentException("Seat is already available");
        }

        seat.setStatus(AVAILABLE);
        Seat updatedSeat = seatRepository.save(seat);
        return mapToResponseDto(updatedSeat);
    }

    private Seat findSeatById(Long id) {
        return seatRepository.findById(id)
                .orElseThrow(() -> new SeatNotFoundException("Seat not found with id: " + id));
    }

    private void validateSeatRequest(SeatRequestDto seatRequestDto) {
        normalizeStatus(seatRequestDto.getStatus());
    }

    private String normalizeStatus(String status) {
        String normalizedStatus = status.trim().toUpperCase();
        if (!AVAILABLE.equals(normalizedStatus) && !RESERVED.equals(normalizedStatus)) {
            throw new IllegalArgumentException("Seat status must be AVAILABLE or RESERVED");
        }
        return normalizedStatus;
    }

    private Seat mapToEntity(SeatRequestDto seatRequestDto) {
        return Seat.builder()
                .flightId(seatRequestDto.getFlightId())
                .seatNumber(seatRequestDto.getSeatNumber())
                .seatType(seatRequestDto.getSeatType())
                .seatClass(seatRequestDto.getSeatClass())
                .price(seatRequestDto.getPrice())
                .status(normalizeStatus(seatRequestDto.getStatus()))
                .build();
    }

    private SeatResponseDto mapToResponseDto(Seat seat) {
        return SeatResponseDto.builder()
                .id(seat.getId())
                .flightId(seat.getFlightId())
                .seatNumber(seat.getSeatNumber())
                .seatType(seat.getSeatType())
                .seatClass(seat.getSeatClass())
                .price(seat.getPrice())
                .status(seat.getStatus())
                .build();
    }
}
