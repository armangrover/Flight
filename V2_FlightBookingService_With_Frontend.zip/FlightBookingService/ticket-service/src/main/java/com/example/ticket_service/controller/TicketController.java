package com.example.ticket_service.controller;

import java.net.URI;
import java.util.List;

import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.support.ServletUriComponentsBuilder;

import com.example.ticket_service.dto.TicketRequestDto;
import com.example.ticket_service.dto.TicketResponseDto;
import com.example.ticket_service.service.TicketService;

import jakarta.validation.Valid;

@RestController
@RequestMapping("/tickets")
@Validated
@CrossOrigin(origins = "http://localhost:5173")
public class TicketController {

    private final TicketService ticketService;

    public TicketController(TicketService ticketService) {
        this.ticketService = ticketService;
    }

    @PostMapping
    public ResponseEntity<TicketResponseDto> createTicket(@Valid @RequestBody TicketRequestDto ticketRequestDto) {
        TicketResponseDto createdTicket = ticketService.createTicket(ticketRequestDto);
        URI location = ServletUriComponentsBuilder.fromCurrentRequest()
                .path("/{id}")
                .buildAndExpand(createdTicket.getId())
                .toUri();
        return ResponseEntity.created(location).body(createdTicket);
    }

    @PostMapping("/generate")
    public ResponseEntity<TicketResponseDto> generateTicket(@Valid @RequestBody TicketRequestDto ticketRequestDto) {
        TicketResponseDto createdTicket = ticketService.generateTicket(ticketRequestDto);
        URI location = ServletUriComponentsBuilder.fromCurrentContextPath()
                .path("/tickets/{id}")
                .buildAndExpand(createdTicket.getId())
                .toUri();
        return ResponseEntity.created(location).body(createdTicket);
    }

    @GetMapping
    public ResponseEntity<List<TicketResponseDto>> getAllTickets() {
        return ResponseEntity.ok(ticketService.getAllTickets());
    }

    @GetMapping("/{id}")
    public ResponseEntity<TicketResponseDto> getTicketById(@PathVariable Long id) {
        return ResponseEntity.ok(ticketService.getTicketById(id));
    }

    @GetMapping("/booking/{bookingId}")
    public ResponseEntity<TicketResponseDto> getTicketByBookingId(@PathVariable Long bookingId) {
        return ResponseEntity.ok(ticketService.getTicketByBookingId(bookingId));
    }

    @PutMapping("/{id}")
    public ResponseEntity<TicketResponseDto> updateTicket(
            @PathVariable Long id,
            @Valid @RequestBody TicketRequestDto ticketRequestDto) {
        return ResponseEntity.ok(ticketService.updateTicket(id, ticketRequestDto));
    }

    @PutMapping("/{id}/cancel")
    public ResponseEntity<TicketResponseDto> cancelTicket(@PathVariable Long id) {
        return ResponseEntity.ok(ticketService.cancelTicket(id));
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteTicket(@PathVariable Long id) {
        ticketService.deleteTicket(id);
        return ResponseEntity.noContent().build();
    }
}
