package com.example.flight_service.service.impl;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;

import org.springframework.stereotype.Service;

import com.example.flight_service.dto.FlightRequestDto;
import com.example.flight_service.dto.FlightResponseDto;
import com.example.flight_service.entity.Flight;
import com.example.flight_service.exception.FlightNotFoundException;
import com.example.flight_service.repository.FlightRepository;
import com.example.flight_service.service.FlightService;

@Service
public class FlightServiceImpl implements FlightService {

    private final FlightRepository flightRepository;

    public FlightServiceImpl(FlightRepository flightRepository) {
        this.flightRepository = flightRepository;
    }

    @Override
    public FlightResponseDto createFlight(FlightRequestDto flightRequestDto) {
        validateFlightRequest(flightRequestDto);
        Flight flight = mapToEntity(flightRequestDto);
        Flight savedFlight = flightRepository.save(flight);
        return mapToResponseDto(savedFlight);
    }

    @Override
    public List<FlightResponseDto> getAllFlights() {
        return flightRepository.findAll()
                .stream()
                .map(this::mapToResponseDto)
                .toList();
    }

    @Override
    public FlightResponseDto getFlightById(Long id) {
        Flight flight = findFlightById(id);
        return mapToResponseDto(flight);
    }

    @Override
    public List<FlightResponseDto> searchFlights(
            String source,
            String destination,
            LocalDate departureDate,
            Integer numberOfPassengers) {
        if (source.equalsIgnoreCase(destination)) {
            throw new IllegalArgumentException("Source and destination cannot be the same");
        }

        return flightRepository
                .findBySourceIgnoreCaseAndDestinationIgnoreCaseAndDepartureDateAndAvailableSeatsGreaterThanEqual(
                        source,
                        destination,
                        departureDate,
                        numberOfPassengers)
                .stream()
                .map(this::mapToResponseDto)
                .toList();
    }

    @Override
    public FlightResponseDto updateFlight(Long id, FlightRequestDto flightRequestDto) {
        validateFlightRequest(flightRequestDto);
        Flight existingFlight = findFlightById(id);

        existingFlight.setFlightNumber(flightRequestDto.getFlightNumber());
        existingFlight.setAirline(flightRequestDto.getAirline());
        existingFlight.setSource(flightRequestDto.getSource());
        existingFlight.setDestination(flightRequestDto.getDestination());
        existingFlight.setDepartureDate(flightRequestDto.getDepartureDate());
        existingFlight.setDepartureTime(flightRequestDto.getDepartureTime());
        existingFlight.setArrivalDate(flightRequestDto.getArrivalDate());
        existingFlight.setArrivalTime(flightRequestDto.getArrivalTime());
        existingFlight.setDuration(flightRequestDto.getDuration());
        existingFlight.setPrice(flightRequestDto.getPrice());
        existingFlight.setAvailableSeats(flightRequestDto.getAvailableSeats());
        existingFlight.setTotalSeats(flightRequestDto.getTotalSeats());
        existingFlight.setFlightStatus(flightRequestDto.getFlightStatus());
        existingFlight.setAircraftType(flightRequestDto.getAircraftType());
        existingFlight.setTerminal(flightRequestDto.getTerminal());
        existingFlight.setGate(flightRequestDto.getGate());

        Flight updatedFlight = flightRepository.save(existingFlight);
        return mapToResponseDto(updatedFlight);
    }

    @Override
    public void deleteFlight(Long id) {
        Flight flight = findFlightById(id);
        flightRepository.delete(flight);
    }

    private Flight findFlightById(Long id) {
        return flightRepository.findById(id)
                .orElseThrow(() -> new FlightNotFoundException("Flight not found with id: " + id));
    }

    private void validateFlightRequest(FlightRequestDto flightRequestDto) {
        if (flightRequestDto.getSource().equalsIgnoreCase(flightRequestDto.getDestination())) {
            throw new IllegalArgumentException("Source and destination cannot be the same");
        }

        if (flightRequestDto.getAvailableSeats() > flightRequestDto.getTotalSeats()) {
            throw new IllegalArgumentException("Available seats cannot be greater than total seats");
        }

        LocalDateTime departureDateTime = LocalDateTime.of(
                flightRequestDto.getDepartureDate(),
                flightRequestDto.getDepartureTime());
        LocalDateTime arrivalDateTime = LocalDateTime.of(
                flightRequestDto.getArrivalDate(),
                flightRequestDto.getArrivalTime());

        if (!arrivalDateTime.isAfter(departureDateTime)) {
            throw new IllegalArgumentException("Arrival date and time must be after departure date and time");
        }
    }

    private Flight mapToEntity(FlightRequestDto flightRequestDto) {
        return Flight.builder()
                .flightNumber(flightRequestDto.getFlightNumber())
                .airline(flightRequestDto.getAirline())
                .source(flightRequestDto.getSource())
                .destination(flightRequestDto.getDestination())
                .departureDate(flightRequestDto.getDepartureDate())
                .departureTime(flightRequestDto.getDepartureTime())
                .arrivalDate(flightRequestDto.getArrivalDate())
                .arrivalTime(flightRequestDto.getArrivalTime())
                .duration(flightRequestDto.getDuration())
                .price(flightRequestDto.getPrice())
                .availableSeats(flightRequestDto.getAvailableSeats())
                .totalSeats(flightRequestDto.getTotalSeats())
                .flightStatus(flightRequestDto.getFlightStatus())
                .aircraftType(flightRequestDto.getAircraftType())
                .terminal(flightRequestDto.getTerminal())
                .gate(flightRequestDto.getGate())
                .build();
    }

    private FlightResponseDto mapToResponseDto(Flight flight) {
        return FlightResponseDto.builder()
                .id(flight.getId())
                .flightNumber(flight.getFlightNumber())
                .airline(flight.getAirline())
                .source(flight.getSource())
                .destination(flight.getDestination())
                .departureDate(flight.getDepartureDate())
                .departureTime(flight.getDepartureTime())
                .arrivalDate(flight.getArrivalDate())
                .arrivalTime(flight.getArrivalTime())
                .duration(flight.getDuration())
                .price(flight.getPrice())
                .availableSeats(flight.getAvailableSeats())
                .totalSeats(flight.getTotalSeats())
                .flightStatus(flight.getFlightStatus())
                .aircraftType(flight.getAircraftType())
                .terminal(flight.getTerminal())
                .gate(flight.getGate())
                .build();
    }
}
