package com.example.booking_service.service.impl;

import java.time.LocalDateTime;
import java.util.List;
import java.util.UUID;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.example.booking_service.client.FlightClient;
import com.example.booking_service.client.SeatClient;
import com.example.booking_service.client.UserClient;
import com.example.booking_service.dto.BookingRequestDto;
import com.example.booking_service.dto.BookingResponseDto;
import com.example.booking_service.dto.SeatResponseDto;
import com.example.booking_service.entity.Booking;
import com.example.booking_service.exception.BookingNotFoundException;
import com.example.booking_service.repository.BookingRepository;
import com.example.booking_service.service.BookingService;

import feign.FeignException;

@Service
public class BookingServiceImpl implements BookingService {

    private static final String AVAILABLE = "AVAILABLE";
    private static final String RESERVED = "RESERVED";

    private final BookingRepository bookingRepository;
    private final UserClient userClient;
    private final FlightClient flightClient;
    private final SeatClient seatClient;

    public BookingServiceImpl(
            BookingRepository bookingRepository,
            UserClient userClient,
            FlightClient flightClient,
            SeatClient seatClient) {
        this.bookingRepository = bookingRepository;
        this.userClient = userClient;
        this.flightClient = flightClient;
        this.seatClient = seatClient;
    }

    @Override
    @Transactional
    public BookingResponseDto createBooking(BookingRequestDto bookingRequestDto) {
        validateBookingRequest(bookingRequestDto);
        verifyUserExists(bookingRequestDto.getUserId());
        verifyFlightExists(bookingRequestDto.getFlightId());
        SeatResponseDto seat = verifySeatForBooking(bookingRequestDto.getSeatId(), bookingRequestDto.getFlightId(), true);

        reserveSeat(bookingRequestDto.getSeatId());

        try {
            Booking booking = Booking.builder()
                    .bookingReference(generateBookingReference())
                    .userId(bookingRequestDto.getUserId())
                    .flightId(bookingRequestDto.getFlightId())
                    .seatId(seat.getId())
                    .bookingDate(LocalDateTime.now())
                    .bookingStatus(normalizeValue(bookingRequestDto.getBookingStatus()))
                    .paymentStatus(normalizeValue(bookingRequestDto.getPaymentStatus()))
                    .totalFare(bookingRequestDto.getTotalFare())
                    .build();

            Booking savedBooking = bookingRepository.save(booking);
            return mapToResponseDto(savedBooking, seat);
        } catch (RuntimeException exception) {
            safelyReleaseSeat(bookingRequestDto.getSeatId());
            throw exception;
        }
    }

    @Override
    public List<BookingResponseDto> getAllBookings() {
        return bookingRepository.findAll()
                .stream()
                .map(this::mapToResponseDto)
                .toList();
    }

    @Override
    public BookingResponseDto getBookingById(Long id) {
        return mapToResponseDto(findBookingById(id));
    }

    @Override
    @Transactional
    public BookingResponseDto updateBooking(Long id, BookingRequestDto bookingRequestDto) {
        validateBookingRequest(bookingRequestDto);
        Booking existingBooking = findBookingById(id);

        verifyUserExists(bookingRequestDto.getUserId());
        verifyFlightExists(bookingRequestDto.getFlightId());

        boolean seatChanged = !existingBooking.getSeatId().equals(bookingRequestDto.getSeatId());
        SeatResponseDto selectedSeat;

        if (seatChanged) {
            selectedSeat = verifySeatForBooking(bookingRequestDto.getSeatId(), bookingRequestDto.getFlightId(), true);
            reserveSeat(bookingRequestDto.getSeatId());
        } else {
            selectedSeat = verifySeatForBooking(bookingRequestDto.getSeatId(), bookingRequestDto.getFlightId(), false);
        }

        Long previousSeatId = existingBooking.getSeatId();

        try {
            existingBooking.setUserId(bookingRequestDto.getUserId());
            existingBooking.setFlightId(bookingRequestDto.getFlightId());
            existingBooking.setSeatId(bookingRequestDto.getSeatId());
            existingBooking.setBookingStatus(normalizeValue(bookingRequestDto.getBookingStatus()));
            existingBooking.setPaymentStatus(normalizeValue(bookingRequestDto.getPaymentStatus()));
            existingBooking.setTotalFare(bookingRequestDto.getTotalFare());

            Booking updatedBooking = bookingRepository.save(existingBooking);

            if (seatChanged) {
                safelyReleaseSeat(previousSeatId);
            }

            return mapToResponseDto(updatedBooking, selectedSeat);
        } catch (RuntimeException exception) {
            if (seatChanged) {
                safelyReleaseSeat(bookingRequestDto.getSeatId());
            }
            throw exception;
        }
    }

    @Override
    @Transactional
    public void deleteBooking(Long id) {
        Booking booking = findBookingById(id);
        bookingRepository.delete(booking);
        safelyReleaseSeat(booking.getSeatId());
    }

    private Booking findBookingById(Long id) {
        return bookingRepository.findById(id)
                .orElseThrow(() -> new BookingNotFoundException("Booking not found with id: " + id));
    }

    private void validateBookingRequest(BookingRequestDto bookingRequestDto) {
        normalizeValue(bookingRequestDto.getBookingStatus());
        normalizeValue(bookingRequestDto.getPaymentStatus());
    }

    private void verifyUserExists(Long userId) {
        try {
            userClient.getUserById(userId);
        } catch (FeignException.NotFound exception) {
            throw new IllegalArgumentException("User not found with id: " + userId);
        } catch (FeignException exception) {
            throw new IllegalStateException("Unable to verify user-service at this time");
        }
    }

    private void verifyFlightExists(Long flightId) {
        try {
            flightClient.getFlightById(flightId);
        } catch (FeignException.NotFound exception) {
            throw new IllegalArgumentException("Flight not found with id: " + flightId);
        } catch (FeignException exception) {
            throw new IllegalStateException("Unable to verify flight-service at this time");
        }
    }

    private SeatResponseDto verifySeatForBooking(Long seatId, Long flightId, boolean mustBeAvailable) {
        SeatResponseDto seat = getSeatById(seatId);

        if (!seat.getFlightId().equals(flightId)) {
            throw new IllegalArgumentException("Selected seat does not belong to the specified flight");
        }

        if (mustBeAvailable && !AVAILABLE.equalsIgnoreCase(seat.getStatus())) {
            throw new IllegalArgumentException("Selected seat is not available");
        }

        return seat;
    }

    private SeatResponseDto getSeatById(Long seatId) {
        try {
            return seatClient.getSeatById(seatId);
        } catch (FeignException.NotFound exception) {
            throw new IllegalArgumentException("Seat not found with id: " + seatId);
        } catch (FeignException exception) {
            throw new IllegalStateException("Unable to verify seat-service at this time");
        }
    }

    private void reserveSeat(Long seatId) {
        try {
            SeatResponseDto seat = seatClient.reserveSeat(seatId);
            if (!RESERVED.equalsIgnoreCase(seat.getStatus())) {
                throw new IllegalStateException("Seat reservation could not be completed");
            }
        } catch (FeignException exception) {
            throw new IllegalStateException("Unable to reserve seat at this time");
        }
    }

    private void safelyReleaseSeat(Long seatId) {
        try {
            SeatResponseDto seat = seatClient.getSeatById(seatId);
            if (RESERVED.equalsIgnoreCase(seat.getStatus())) {
                seatClient.releaseSeat(seatId);
            }
        } catch (FeignException exception) {
            throw new IllegalStateException("Unable to release seat at this time");
        }
    }

    private String generateBookingReference() {
        return "BKG-" + UUID.randomUUID().toString().replace("-", "").substring(0, 10).toUpperCase();
    }

    private String normalizeValue(String value) {
        return value.trim().toUpperCase();
    }

    private BookingResponseDto mapToResponseDto(Booking booking) {
        return mapToResponseDto(booking, getSeatById(booking.getSeatId()));
    }

    private BookingResponseDto mapToResponseDto(Booking booking, SeatResponseDto seat) {
        return BookingResponseDto.builder()
                .id(booking.getId())
                .bookingReference(booking.getBookingReference())
                .userId(booking.getUserId())
                .flightId(booking.getFlightId())
                .seatId(booking.getSeatId())
                .seatNumber(seat.getSeatNumber())
                .bookingDate(booking.getBookingDate())
                .bookingStatus(booking.getBookingStatus())
                .paymentStatus(booking.getPaymentStatus())
                .totalFare(booking.getTotalFare())
                .build();
    }
}
