# Flight Booking System - Backend Feature Expansion

## IMPORTANT

This repository contains an EXISTING and WORKING Java Spring Boot backend.

The backend is already functional.

DO NOT redesign the project.

DO NOT rewrite existing architecture.

DO NOT rename packages.

DO NOT rename classes.

DO NOT rename existing endpoints unless absolutely necessary.

DO NOT remove existing functionality.

DO NOT break existing APIs.

DO NOT generate or modify any frontend code.

DO NOT create React components, HTML, CSS, or JavaScript.

This task is BACKEND ONLY.

Always reuse the existing implementation whenever possible.

Only add new classes if absolutely necessary.

Keep all changes incremental and compatible with the current codebase.

------------------------------------------------------------

# Existing Architecture

The project currently consists of these independent Spring Boot microservices:

- user-service
- flight-service
- search-service
- booking-service
- seat-service
- ticket-service

The current workflow already works:

User
↓

Search Flight
↓

Choose Seat
↓

Create Booking
↓

Reserve Seat
↓

Generate Ticket

This workflow must continue to work after all new features are added.

------------------------------------------------------------

# Tech Stack

- Java
- Spring Boot
- Spring Data JPA
- Spring Security
- JWT
- MySQL
- Maven
- OpenFeign
- Lombok

Follow the existing coding style.

Reuse existing DTOs, Services and Repositories wherever possible.

------------------------------------------------------------

# BEFORE WRITING CODE

Before implementing anything:

Analyze the existing project.

Understand:

• Existing entities

• Existing DTOs

• Existing controllers

• Existing services

• Existing database relationships

• Existing Feign communication

Reuse the existing code whenever possible.

Avoid creating duplicate functionality.

------------------------------------------------------------

# IMPLEMENT FEATURES IN THIS ORDER

Implement one feature completely before moving to the next.

After each feature:

• Verify the project compiles successfully.

• Verify existing functionality still works.

• Fix any compile/runtime issues.

• Update ADDITIONAL_FEATURES.md.

Then continue to the next feature.

------------------------------------------------------------

# FEATURE 1

JWT Authentication

Implement secure authentication.

Requirements:

• User Registration

• User Login

• BCrypt password hashing

• JWT Token generation

• JWT validation

• Spring Security configuration

• Role Based Authorization

Create two roles:

ROLE_USER

ROLE_ADMIN

Every newly registered account should automatically receive ROLE_USER.

Passwords must never be stored in plain text.

------------------------------------------------------------

Authentication APIs

Implement endpoints similar to:

POST /auth/register

POST /auth/login

GET /users/me

Login should return a JWT token.

------------------------------------------------------------

Public Endpoints

These should remain publicly accessible:

Authentication

Flight Search

Flight Listing

------------------------------------------------------------

Protected USER Endpoints

Authenticated users should be able to:

View Profile

Update Profile

View Booking History

Book Flights

Cancel Bookings

Download Ticket PDF

------------------------------------------------------------

Protected ADMIN Endpoints

Only ROLE_ADMIN should access:

Create Flight

Update Flight

Delete Flight

Create Seat

Update Seat

Delete Seat

View All Users

View All Bookings

------------------------------------------------------------

# FEATURE 2

User Profile

Implement profile functionality.

Users should be able to:

View Profile

Update Profile

View Booking History

Booking history should include:

Booking

Flight

Seat

Ticket

Booking Status

Booking Date

Fare

------------------------------------------------------------

# FEATURE 3

Booking Cancellation

Implement booking cancellation.

Do NOT permanently delete bookings.

Instead:

Booking Status -> CANCELLED

Release reserved seat.

Synchronize flight available seats.

If ticket exists:

Ticket Status -> CANCELLED

Do not physically delete records.

------------------------------------------------------------

# FEATURE 4

Synchronize Flight Seat Count

Whenever:

Seat Reserved

↓

Decrease Flight.availableSeats

Whenever:

Seat Released

↓

Increase Flight.availableSeats

Search results should always display the correct seat count.

------------------------------------------------------------

# FEATURE 5

Ticket PDF Download

Implement ticket PDF generation.

Use OpenPDF (preferred).

Do not use paid libraries.

Implement endpoint similar to:

GET /tickets/{ticketId}/download

Return:

Content-Type: application/pdf

The PDF should contain:

Passenger Name

Booking ID

Ticket ID

Flight Number

Airline

Source

Destination

Departure Date

Departure Time

Arrival Date

Arrival Time

Seat Number

Terminal

Gate

Booking Status

Fare

Generation Date

Keep the PDF simple and professional.

Do NOT add:

QR Codes

Barcodes

Airline Logos

Complex Graphics

Fancy Styling

Focus on correctness and readability.

------------------------------------------------------------

# GENERAL REQUIREMENTS

Maintain the current microservice architecture.

Use constructor injection.

Continue using DTOs.

Do not expose entities directly.

Use validation.

Use proper exception handling.

Use ResponseEntity where appropriate.

Follow REST principles.

Reuse existing repositories and services.

Only introduce new entities if absolutely required.

------------------------------------------------------------

# DOCUMENTATION

Create a file named:

ADDITIONAL_FEATURES.md

Document every new feature.

For every endpoint include:

• HTTP Method

• URL

• Purpose

• Service Name

• Authentication Required

• Required Role

• Request JSON

• Response JSON

• Possible Status Codes

Also document:

New Database Fields

New Tables

New Entities

New DTOs

New Dependencies

JWT Configuration

Authentication Flow

Booking Cancellation Flow

Ticket PDF Flow

Frontend Integration Notes

------------------------------------------------------------

Also create:

API_REFERENCE.md

This should contain EVERY endpoint in the project, including both old and newly added endpoints.

For every endpoint document:

Service

Method

URL

Description

Authentication Required

Role Required

Request Body

Response Body

Example JSON

This file will serve as the API documentation for frontend integration.

------------------------------------------------------------

# FINAL REVIEW

After all implementation is complete:

Review the entire backend.

Check for:

Compile Errors

Dependency Issues

Package Issues

Spring Boot Compatibility

OpenFeign Compatibility

DTO Mapping

Entity Relationships

Security Configuration

Exception Handling

Unused Code

Broken Endpoints

Duplicate Logic

Fix every issue found.

Ensure all existing functionality continues to work.

Do NOT modify or generate frontend code.

The final backend should build successfully and all services should remain functional.