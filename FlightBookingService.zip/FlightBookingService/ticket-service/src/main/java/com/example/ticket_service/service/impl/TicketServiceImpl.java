package com.example.ticket_service.service.impl;

import java.time.LocalDateTime;
import java.util.List;
import java.util.UUID;

import org.springframework.stereotype.Service;

import com.example.ticket_service.client.BookingClient;
import com.example.ticket_service.dto.BookingResponseDto;
import com.example.ticket_service.dto.TicketRequestDto;
import com.example.ticket_service.dto.TicketResponseDto;
import com.example.ticket_service.entity.Ticket;
import com.example.ticket_service.exception.TicketNotFoundException;
import com.example.ticket_service.repository.TicketRepository;
import com.example.ticket_service.service.TicketService;

import feign.FeignException;

@Service
public class TicketServiceImpl implements TicketService {

    private static final String CANCELLED = "CANCELLED";

    private final TicketRepository ticketRepository;
    private final BookingClient bookingClient;

    public TicketServiceImpl(TicketRepository ticketRepository, BookingClient bookingClient) {
        this.ticketRepository = ticketRepository;
        this.bookingClient = bookingClient;
    }

    @Override
    public TicketResponseDto createTicket(TicketRequestDto ticketRequestDto) {
        return generateTicket(ticketRequestDto);
    }

    @Override
    public TicketResponseDto generateTicket(TicketRequestDto ticketRequestDto) {
        validateTicketRequest(ticketRequestDto);
        BookingResponseDto booking = verifyBooking(ticketRequestDto.getBookingId());

        Ticket ticket = Ticket.builder()
                .ticketNumber(generateTicketNumber())
                .bookingId(booking.getId())
                .flightId(booking.getFlightId())
                .userId(booking.getUserId())
                .seatNumber(ticketRequestDto.getSeatNumber().trim().toUpperCase())
                .issueDate(LocalDateTime.now())
                .ticketStatus(normalizeStatus(ticketRequestDto.getTicketStatus()))
                .build();

        Ticket savedTicket = ticketRepository.save(ticket);
        return mapToResponseDto(savedTicket);
    }

    @Override
    public List<TicketResponseDto> getAllTickets() {
        return ticketRepository.findAll()
                .stream()
                .map(this::mapToResponseDto)
                .toList();
    }

    @Override
    public TicketResponseDto getTicketById(Long id) {
        return mapToResponseDto(findTicketById(id));
    }

    @Override
    public TicketResponseDto getTicketByBookingId(Long bookingId) {
        Ticket ticket = ticketRepository.findByBookingId(bookingId)
                .orElseThrow(() -> new TicketNotFoundException("Ticket not found for booking id: " + bookingId));
        return mapToResponseDto(ticket);
    }

    @Override
    public TicketResponseDto updateTicket(Long id, TicketRequestDto ticketRequestDto) {
        validateTicketRequest(ticketRequestDto);
        BookingResponseDto booking = verifyBooking(ticketRequestDto.getBookingId());
        Ticket existingTicket = findTicketById(id);

        existingTicket.setBookingId(booking.getId());
        existingTicket.setFlightId(booking.getFlightId());
        existingTicket.setUserId(booking.getUserId());
        existingTicket.setSeatNumber(ticketRequestDto.getSeatNumber().trim().toUpperCase());
        existingTicket.setTicketStatus(normalizeStatus(ticketRequestDto.getTicketStatus()));

        Ticket updatedTicket = ticketRepository.save(existingTicket);
        return mapToResponseDto(updatedTicket);
    }

    @Override
    public TicketResponseDto cancelTicket(Long id) {
        Ticket ticket = findTicketById(id);
        ticket.setTicketStatus(CANCELLED);
        Ticket updatedTicket = ticketRepository.save(ticket);
        return mapToResponseDto(updatedTicket);
    }

    @Override
    public void deleteTicket(Long id) {
        Ticket ticket = findTicketById(id);
        ticketRepository.delete(ticket);
    }

    private Ticket findTicketById(Long id) {
        return ticketRepository.findById(id)
                .orElseThrow(() -> new TicketNotFoundException("Ticket not found with id: " + id));
    }

    private void validateTicketRequest(TicketRequestDto ticketRequestDto) {
        normalizeStatus(ticketRequestDto.getTicketStatus());
    }

    private BookingResponseDto verifyBooking(Long bookingId) {
        try {
            BookingResponseDto booking = bookingClient.getBookingById(bookingId);
            if (CANCELLED.equalsIgnoreCase(booking.getBookingStatus())) {
                throw new IllegalArgumentException("Cannot generate ticket for a cancelled booking");
            }
            return booking;
        } catch (FeignException.NotFound exception) {
            throw new IllegalArgumentException("Booking not found with id: " + bookingId);
        } catch (FeignException exception) {
            throw new IllegalStateException("Unable to verify booking-service at this time");
        }
    }

    private String generateTicketNumber() {
        return "TKT-" + UUID.randomUUID().toString().replace("-", "").substring(0, 10).toUpperCase();
    }

    private String normalizeStatus(String status) {
        return status.trim().toUpperCase();
    }

    private TicketResponseDto mapToResponseDto(Ticket ticket) {
        return TicketResponseDto.builder()
                .id(ticket.getId())
                .ticketNumber(ticket.getTicketNumber())
                .bookingId(ticket.getBookingId())
                .flightId(ticket.getFlightId())
                .userId(ticket.getUserId())
                .seatNumber(ticket.getSeatNumber())
                .issueDate(ticket.getIssueDate())
                .ticketStatus(ticket.getTicketStatus())
                .build();
    }
}
