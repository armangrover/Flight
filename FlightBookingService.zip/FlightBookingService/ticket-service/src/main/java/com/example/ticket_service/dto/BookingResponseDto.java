package com.example.ticket_service.dto;

import java.math.BigDecimal;
import java.time.LocalDateTime;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class BookingResponseDto {

    private Long id;
    private String bookingReference;
    private Long userId;
    private Long flightId;
    private Long seatId;
    private LocalDateTime bookingDate;
    private String bookingStatus;
    private String paymentStatus;
    private BigDecimal totalFare;
}
