package com.example.ticket_service.dto;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Positive;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class TicketRequestDto {

    @NotNull(message = "Booking id is required")
    @Positive(message = "Booking id must be greater than zero")
    private Long bookingId;

    @NotBlank(message = "Seat number is required")
    private String seatNumber;

    @NotBlank(message = "Ticket status is required")
    private String ticketStatus;
}
