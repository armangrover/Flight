package com.example.flight_service.service;

import java.util.List;

import com.example.flight_service.dto.FlightRequestDto;
import com.example.flight_service.dto.FlightResponseDto;

public interface FlightService {

    FlightResponseDto createFlight(FlightRequestDto flightRequestDto);

    List<FlightResponseDto> getAllFlights();

    FlightResponseDto getFlightById(Long id);

    FlightResponseDto updateFlight(Long id, FlightRequestDto flightRequestDto);

    void deleteFlight(Long id);
}
