package com.example.flight_service.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.flight_service.entity.Flight;

public interface FlightRepository extends JpaRepository<Flight, Long> {
}
