package com.example.search_service.client;

import java.util.List;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;

import com.example.search_service.dto.FlightResponseDto;

@FeignClient(name = "flight-service-client", url = "${flight.service.url}")
public interface FlightClient {

    @GetMapping("/flights")
    List<FlightResponseDto> getAllFlights();
}
